//Variables

var page = require('showtime/page');
var service = require('showtime/service');
var settings = require('showtime/settings');
var http = require('showtime/http');
var string = require('native/string');
var popup = require('native/popup');
var io = require('native/io');
var store = require('movian/store');
var plugin = JSON.parse(Plugin.manifest);
var logo = Plugin.path + plugin.icon;
var localVersion = plugin.version;

var tosSave = store.create('tosSave');
if (!tosSave.list) {
  tosSave.list = '[]';
}

var codeSave = store.create('codeSave');
if (!codeSave.list) {
  codeSave.list = '[]';
}

var favorites = store.create('favorites');
if (!favorites.list) {
  favorites.list = '[]';
}

var history = store.create('history');
if (!history.list) {
  history.list = '[]';
}

var playList = store.create('playList');
if (!playList.list) {
  playList.list = '[]';
}

var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36';

var jsonData = {}, jsonIptv = {}, m3uItems = [], groups = [], background = '', theLastList = '', m3uLinks = '', theLastSearch = '', code = '1508laal', numerPages = 1, codeVerify = false, tosAccepted = false;

var base = "https://playstr3am.netlify.app/", scrapper = base + ".netlify/functions/";

var blue = '6699CC', orange = 'FFA500', red = 'EE0000', green = '008B45', violet = '9A4DAD';

var generos = ["2025", "Acción", "Animación", "Aventura", "Bélico", "Ciencia ficción", "Comedia",
               "Crimen", "Documental", "Drama", "Familia", "Fantasía", "Historia", "Música",
               "Misterio", "Película de TV", "Romance", "Suspenso", "Terror", "Western"];

var tos = "Este plugin se proporciona con fines educativos y de aprendizaje. El creador no se hace responsable del uso que se le dé ni del contenido reproducido, el cual puede ser de terceros. El usuario asume toda la responsabilidad legal sobre el uso del plugin, asegurándose de que no infrinja derechos de autor ni leyes locales. El creador no será responsable por daños, pérdidas o problemas legales derivados del uso del plugin. El plugin está destinado a uso personal y no debe ser modificado ni distribuido para fines comerciales sin permiso. Al utilizar este plugin, aceptas estos términos.";

//Funciones

RichText = function(x) {
  this.str = x.toString();
};

RichText.prototype.toRichString = function(x) {
  return this.str;
};

function coloredStr(str, color) {
  return '<font color="' + color + '">' + str + '</font>';
}

function trim(s) {
  if (s) return s.replace(/(\r\n|\n|\r)/gm, '').replace(/(^\s*)|(\s*$)/gi, '').replace(/[ ]{2,}/gi, ' ').replace(/\t/g, '');
  return '';
}

function log(str) {
  if (service.debug) {
    console.log(str);
    print(str);
  }
}

function setPageHeader(page, title) {
  page.loading = true;
  page.type = 'directory';
  page.contents = 'items';
  page.model.contents = 'grid';
  page.metadata.icon = logo;
  page.entries = 0;

  if (page.metadata) {
    page.metadata.title = new RichText(decodeURIComponent(title));
    page.metadata.logo = logo;
  }

  if (!service.disableBackground) {
    page.metadata.background = Plugin.path + 'images/background.jpg';
  }

  if (codeVerify) {
    accesUrl(page);
  }
}

function checkUpdate(page) {
  resp = http.request(base + "plugin.json").toString();
  console.log(resp);
  const latestVersion = JSON.parse(resp).version;

  if (localVersion < latestVersion) {
    popup.notify("Version Actual: " + localVersion + ", Nueva Version Disponible: " + latestVersion, 5);
    popup.notify("Actualiza PlayStr3am desde el menu lateral.  (Triangulo)", 0xa);

    page.options.createAction("update", "Actualizar PlayStr3am", function () {
      popup.notify("Actualizando, espere 10 segundos y regrese atras...",0xa );
      page.redirect(base + "PlayStr3am.zip");
    });
  }
}

function accesUrl(page) {
  var codeSaveData = [];

  try {
      codeSaveData = JSON.parse(codeSave.list || '[]');
  } catch (e) {
      codeSaveData = [];
  }

  if (codeSave.list === '[]') {
    var credentials = popup.getAuthCredentials(plugin.id, 'Ingresa tu Código para continuar', codeVerify, 'PlayStr3am');

    if (credentials.rejected) {
      page.error('No se puede continuar sin nombre de usuario y/o contraseña :(');
      return false;
    }

    if (credentials && credentials.password && credentials.username) {    
      var entry = JSON.stringify({
        name: credentials.username,
        code: credentials.password,
      });

      codeSaveData = JSON.parse(codeSave.list || '[]');
      codeSaveData.unshift(entry);
      codeSave.list = JSON.stringify(codeSaveData);
    }
  }

  try {
    var credentialsSave = JSON.parse(codeSaveData[0]);
    code = credentialsSave.code;

    var response = http.request(scrapper + "code?codigo=" + credentialsSave.code, {
        method: 'GET',
        headers: { 'User-Agent': UA }
    });

    popup.notify("Codigo Verificado", 5);
    popup.notify("¡Bienvenid@, " + credentialsSave.name + "! Disfruta del Contenido.",5 );

    if (response.status < 200 || response.status >= 300 || response.status >= 500) {
        codeSave.list = '[]';
        popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'", 0xa);
        throw new Error('Tu Código Expiró, Genera uno Nuevo');
    } else {
        codeVerify = false;
    }

    return true;
  } catch (e) {
    codeSave.list = '[]';
    popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'", 0xa);
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return false;
  }
}

//Configuraciones

service.create(plugin.title, plugin.id + ':start', 'PlayStr3am', true, logo);
settings.globalSettings(plugin.id, plugin.title, logo, plugin.synopsis);

settings.createDivider("IPTV");

settings.createMultiOpt('selectCountry', 'Escoger Region', [
    ['Argentina', 'Argentina'],
    ['Bolivia', 'Bolivia'],
    ['Brasil', 'Brasil'],
    ['Canada', 'Canada'],
    ['Chile', 'Chile'],
    ['Colombia', 'Colombia'],
    ['Costa Rica', 'Costa Rica'],
    ['Cuba', 'Cuba'],
    ['Ecuador', 'Ecuador'],
    ['España', 'España'],
    ['Guatemala', 'Guatemala'],
    ['Honduras', 'Honduras'],
    ['Mexico', 'Mexico'],
    ['Nicaragua', 'Nicaragua'],
    ['Panama', 'Panama'],
    ['Paraguay', 'Paraguay'],
    ['Peru', 'Peru'],
    ['Puerto Rico', 'Puerto Rico'],
    ['Republica Dominicana', 'Republica Dominicana'],
    ['Salvador', 'Salvador'],
    ['Uruguay', 'Uruguay'],
    ['USA', 'USA'],
    ['Venezuela', 'Venezuela'],
    ['undefined', 'undefined', true],
  ], function(v) {
  service.selectCountry = v;
});
settings.createBool('disableAdultos', 'Mostrar Contenido +18', false, function(v) {
  service.disableAdultos = v;
});

settings.createDivider("Listas M3U");

settings.createBool('enabledM3uOp', 'Optimizar Listas Grandes', false, function(v) {
  service.disableM3uOp = v;
});
settings.createBool('disablePlayList', 'Ocultar Listas', false, function(v) {
  service.disablePlayList = v;
});
settings.createAction('cleanPlayList', 'Vacía Tus Listas', function() {
  playList.list = '[]';
  popup.notify('Tus Listas M3U se han vaciado exitosamente', 2);
});

settings.createDivider("Pagina Principal");

settings.createBool('disableGenres', 'Ocultar Generos', false, function(v) {
  service.disableGenres = v;
});
settings.createBool("backgroundEnabled", "Ocultar Background", false, function(v) {
  service.disableBackground = v;
});
settings.createAction('closeSesion', 'Cerrar Sesion', function() {
  codeVerify = true;
  codeSave.list = '[]';
  popup.notify('Sesion cerrada exitosamente', 2);
});

// Principal

function mainPage(page) {
  setPageHeader(page, plugin.title);
  var historial = JSON.parse(history.list || '[]');
  var favoritos = JSON.parse(favorites.list || '[]');
  var playLists = JSON.parse(playList.list || '[]');
  numerPages = 1;

  if (tosSave.list === '[]') {
    if (popup.message(tos, true, true)) {
      tosAccepted = true;
      tosSave.list = '[1]';
    } else {
      page.error('No puedes usar el plugin sin aceptar los Términos y Condiciones.');
      return;
    }
  }

  checkUpdate(page);
  addListM3u(page);

  page.options.createAction('gotoIptv', 'IPTV', function() {
    page.redirect(plugin.id + ':iptv');
  });

  page.options.createAction('gotoInternetArchive', 'Internet Archive', function() {
    page.redirect(plugin.id + ':internetArchive:');
  });

  if (historial.length > 0) {
    page.options.createAction('gotoHistorial', 'Historial', function() {
      page.redirect(plugin.id + ':favoritesandRecord:history');
    });
  }

  if (favoritos.length > 0) {
    page.options.createAction('gotoFavoritos', 'Favoritos', function() {
      page.redirect(plugin.id + ':favoritesandRecord:favorites');
    });
  }

  page.appendItem("searchJson:", "search", {
      title: "Buscar Peliculas y Series...",
  });
  page.appendItem('', 'separator', {
    title: '',
  });

  if (!service.disableGenres) {
    for (var i = 0; i < generos.length; i++) {
      var image = Plugin.path + 'images/genres/' + encodeURIComponent(generos[i]) + '.png';
      addItem(page, '', '', image, '', '', '', 'searchJson:' + generos[i]);
    } 
  }

  if (!service.disablePlayList && playLists.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i> Listas M3U</i> ==★== </b>', orange)),
    });

    showListM3u(page);  
  }
  page.loading = false;
}

//Favoritos 

function addOptionForAddingToMyFavorites(item, route, title, icon, cast, duracion, genres, similar, sinopsis, type) {
  item.addOptAction('Agrega \'' + title + '\' a Tus Favoritos', function() {
    var entry = JSON.stringify({  
      route: route, title: title, icon: icon, cast: cast, duracion: duracion, genres: genres, similar: similar, sinopsis: sinopsis, type: type,
    });
    favorites.list = JSON.stringify([entry].concat(eval(favorites.list)));
    popup.notify('\'' + title + '\' a sido Agregado a Tus Favoritos.', 2);
  });
}

function addOptionForRemovingFromMyFavorites(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de Tus Favoritos?', function() {
    var list = JSON.parse(favorites.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminado de Tus Favoritos.', 2);
    list.splice(pos, 1);
    favorites.list = JSON.stringify(list);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function showFavorites(page) {
  var list;
  try {
    list = JSON.parse(favorites.list);
  } catch (e) {
    list = [];
  }

  var parsedFavorite = [];
  for (var i in list) {
    try {
      parsedFavorite.push(JSON.parse(list[i]));
    } catch (e) {}
  }

  var ruteRemoving = (parsedFavorite.length === 1 ? ':start' : ':favoritesandRecord:');
  var pos = 0;
  var sections = [
    { name: "Películas y Series", types: ['json', 'history'] },
    { name: "Internet Archive y M3U", types: ['m3u', 'archive'] },
    { name: "Multimedia", types: ['video'] }
  ];

  for (var s = 0; s < sections.length; s++) {
    var currentSection = sections[s];
    var items = parsedFavorite.filter(function(item) {
      return currentSection.types.indexOf(item.type) !== -1;
    });

    if (items.length > 0) {
      page.appendItem('', 'separator', {
        title: new RichText(coloredStr('<b>==★== <i>' + currentSection.name + '</i> ==★== </b>', orange))
      });

      for (var j = 0; j < items.length; j++) {
        var itemmd = items[j];
        var decodedIcon = itemmd.icon ? itemmd.icon : Plugin.path + 'images/video.png';
        //var route = getFavoriteRoute(itemmd, itemmd.link, itemmd.title, decodedIcon);
        var duracion = new RichText(itemmd.duracion ? coloredStr(itemmd.duracion, blue) : '');
        var genresText = itemmd.genres ? coloredStr('Género: ', violet) + itemmd.genres : '';
        var castText = itemmd.cast ? '\n' + coloredStr('Cast: ', blue) + itemmd.cast : '';
        var similarText = itemmd.similar ? '\n' + coloredStr('Recomendado: ', green) + itemmd.similar : '';
        var sinopsisText = itemmd.sinopsis ? '\n' + coloredStr('Sinopsis: ', orange) + itemmd.sinopsis : '';
        var description = new RichText(genresText + castText + similarText + sinopsisText);
        var item = addItem(page, '', itemmd.title, decodedIcon, description, duracion, '', itemmd.route);
        addOptionForRemovingFromMyFavorites(page, item, itemmd.title, pos, ruteRemoving);
        pos++;
      }
    }
  }
}

function favoriteAndPagesHistory(page, route) {
  page.options.createAction('gotoInicio', 'Inicio', function() {
    page.redirect(plugin.id + ':start');
  });

  if (route === 'favorites') {
    setPageHeader(page, 'Tus Favoritos');
    showFavorites(page);

    page.options.createAction('cleanFavorites', 'Vacía Tus Favoritos', function() {
      favorites.list = '[]';
      popup.notify('Tus Favoritos se han vaciado exitosamente', 3);
      page.redirect(plugin.id + ':start');
    });
    popup.notify("Puedes borrar todos Tus Favoritos desde el menu lateral. (Triangulo)", 3);
  } else if (route === 'history'){
    setPageHeader(page, "Historial de Busquedas");
    showHistory(page);

    page.options.createAction('cleanRecord', 'Vacía Tu Historial', function() {
      history.list = '[]';
      popup.notify('Tu Historial de Busqueda se ha vaciado exitosamente', 3);
      page.redirect(plugin.id + ':start');
    });  
    popup.notify("Puedes borrar todo Tu Historial desde el menu lateral. (Triangulo)", 3);
  }
  page.loading = false;
}

//BUSCAR

function addSearchToHistory(page, title, type) {
    try {
        if (title) {
            for (var i = 0; i < generos.length; i++) {
                if (generos[i].toLowerCase() === title.toLowerCase()) {
                    return;
                }
            }

            var historyData = JSON.parse(history.list || '[]');

            for (var i = 0; i < historyData.length; i++) {
                try {
                    var existingEntry = JSON.parse(historyData[i]);
                    if (existingEntry.title.toLowerCase() === title.toLowerCase() && existingEntry.type.toLowerCase() === type.toLowerCase()) {
                        return;
                    }
                } catch (e) {
                }
            }

            var entry = JSON.stringify({ title: title, type: type });
            historyData.unshift(entry);
            history.list = JSON.stringify(historyData);
        }
    } catch (e) {
        popup.notify('Error al guardar la búsqueda: ' + e.message, 5);
    }
}

function addOptionForRemovingFromMyHistory(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de tu Historial?', function() {
    var historyData = JSON.parse(history.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminada.', 2);
    historyData.splice(pos, 1);
    history.list = JSON.stringify(historyData);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function showHistory(page) {
    var historyData = [];
    try {
        historyData = JSON.parse(history.list || '[]');
    } catch (e) {
        historyData = [];
    }
    
    var parsedHistory = [];
    for (var i in historyData) {
        try {
            parsedHistory.push(JSON.parse(historyData[i]));
        } catch (e) {}
    }
 

    var ruteRemoving = (parsedHistory.length === 1 ? ':start' : ':favoritesandRecord:');
    
    var pos = 0;
    var sections = [
        { type: 'movie', seccion: 'Películas y Series', routePrefix: 'searchJson:', image: Plugin.path + 'images/search.png' },
        { type: 'iptv', seccion: 'IPTV', routePrefix: 'iptvJson::', image: Plugin.path + 'images/search.png' },
        { type: 'archive', seccion: 'Internet Archive', routePrefix: 'internetArchiveFiles::', image: Plugin.path + 'images/internet.jpg' }
    ];
    
    for (var s = 0; s < sections.length; s++) {
        var currentSection = sections[s];
        var items = parsedHistory.filter(function(item) {
            return item.type === currentSection.type;
        });
        
        if (items.length > 0) {
            page.appendItem('', 'separator', {
                title: new RichText(coloredStr('<b>==★== <i>' + currentSection.seccion + '</i> ==★== </b>', orange))
            });
            
            for (var j = 0; j < items.length; j++) {
                var itemmd = items[j];
                var route = currentSection.routePrefix + itemmd.title;

                var item = addItem(page, '', itemmd.title, currentSection.image, '', '', '', route);                
                addOptionForAddingToMyFavorites(item, route, itemmd.title, currentSection.image, '', '', '', '', '', 'history');
                addOptionForRemovingFromMyHistory(page, item, itemmd.title, pos, ruteRemoving);
                pos++;
            }
        }
    }
}


//ProcesarM3U

function isPlaylist(pl) {
  pl = unescape(pl).toUpperCase();
  var extension = pl.split('.').pop();
  var lastPart = pl.split('/').pop();
  if (pl.substr(0, 4) == 'M3U:' || (extension == 'M3U' && pl.substr(0, 4) != 'HLS:') || lastPart == 'PLAYLIST' ||
    pl.match(/TYPE=M3U/) || pl.match(/BIT.DO/) || pl.match(/BIT.LY/) || pl.match(/GOO.GL/) ||
    pl.match(/TINYURL.COM/) || pl.match(/RAW.GITHUB/) || pl.match(/PS3.PHP?/)) {
    return 'm3u';
  }
  return false;
}

function addListM3u(page) {
  page.options.createAction('addPlaylistM3u', 'Ingresar lista M3U', function() {
    var result = popup.textDialog('Ingresa la URL de tu lista M3U:\n' +
      'http://bit.ly/ejemplo o bit.ly/ejemplo o solo ejemplo', true, true);
    if (!result.rejected && result.input) {
      var link = result.input;
      if (!link.match(/\./)) {
        link = 'http://bit.ly/' + link;
      }
      if (!link.match(/:\/\//)) {
        link = 'http://' + link;
      }
      var result = popup.textDialog('Ingresa el nombre de tu lista M3U:', true, true);
      if (!result.rejected && result.input) {
        var entry = JSON.stringify({
          title: result.input,
          link: encodeURIComponent(link),
        });
        playList.list = JSON.stringify([entry].concat(eval(playList.list)));
        popup.notify(result.input + ' - A sido añadida a tus listas', 2);
        page.flush();
        page.redirect(plugin.id + ':start');
      }
    }
  });
}

function addOptionForRemovingFromMyPlayList(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de Tus Listas M3U?', function() {
    var list = JSON.parse(playList.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminado de Tus Listas.', 2);
    list.splice(pos, 1);
    playList.list = JSON.stringify(list);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function showListM3u(page) {
  var list;
  try {
    list = JSON.parse(playList.list);
  } catch (e) {
    list = [];
  }

  var pos = 0;
  for (var i in list) {
    var itemmd = JSON.parse(list[i]);
    var route = 'listM3u:' + itemmd.link + ':listM3u:' + itemmd.title;

    var item = addItem(page, '', itemmd.title, Plugin.path + 'images/several.jpg', '', '', '', route);
    addOptionForRemovingFromMyPlayList(page, item, itemmd.title, pos, ':start');
    pos++;
  }
}

function readAndParseM3U(page, pl, m3u) { 
  var title = page.metadata.title;
  page.loading = true;
  if (!m3u) {
    page.metadata.title = 'Buscando Opciones...';
    log('Fetching: ' + decodeURIComponent(pl));
    m3u = http.request(decodeURIComponent(pl), {
      headers: {
        'User-Agent': UA,
      },
    }).toString().split('\n');
  };
  theLastList = pl;
  m3uItems = [];
  groups = [];
  var m3uUrl = '',
    m3uTitle = '',
    m3uImage = '',
    m3uGroup = '';
  var line = '',
    m3uRegion = '',
    m3uEpgId = '',
    m3uHeaders = '';
  m3uUA = '';

   console.log("Elementos cargados en m3uItems:", m3uItems);

  for (var i = 0; i < m3u.length; i++) {
    page.metadata.title = 'Cargando Contenido...';
    line = m3u[i].trim();
    if (line.substr(0, 7) != '#EXTM3U' && line.indexOf(':') < 0 && line.length != 40) continue;
    line = string.entityDecode(line.replace(/[\u200B-\u200F\u202A-\u202E]/g, ''));

    switch (line.substr(0, 7)) {
      case '#EXTM3U':
        var match = line.match(/region=(.*)\b/);
        if (match) {
          m3uRegion = match[1];
        }
        break;

      case '#EXTINF':
        var match = line.match(/#EXTINF:.*,(.*)/);
        if (match) {
          m3uTitle = match[1].trim();
        }

        match = line.match(/group-title="([\s\S]*?)"/);
        if (match) {
          m3uGroup = match[1].trim();
          if (groups.indexOf(m3uGroup) < 0) {
            groups.push(m3uGroup);
          }
        }

        match = line.match(/tvg-logo=["|”]([\s\S]*?)["|”]/);
        if (match) {
          m3uImage = match[1].trim();
        }

        m3uItems.push({
          title: m3uTitle ? m3uTitle : line,
          url: m3u[i + 1] ? m3u[i + 1].trim() : 'URL no disponible', // URL es la línea siguiente
          group: m3uGroup,
          logo: m3uImage,
          region: m3uRegion,
        });

        m3uUrl = '', m3uTitle = '', m3uImage = '', m3uGroup = '';
        break;
    }
  }
  console.log("Elementos cargados en m3uItems:", m3uItems);
  page.metadata.title = title;
}

function addItem(page, url, title, icon, description, duracion, sinopsis, route) {
  if (route === '') {
    var type = 'video';
    var link = url.match(/([\s\S]*?):(.*)/);
    var linkUrl = 0;
    var playlistType = isPlaylist(url);
    if (playlistType) {
      link = linkUrl = 'listM3u:' + encodeURIComponent(url) + ':listM3u:' + escape(title);
      type = 'm3u';
    } else if (link && !link[1].toUpperCase().match(/HTTP/) && !link[1].toUpperCase().match(/RTMP/)) {
      link = linkUrl = plugin.id + ':' + url + ':' + escape(title);
    } else {
      linkUrl = url.toUpperCase().match(/M3U8/) || url.toUpperCase().match(/\.SMIL/) ? 'hls:' + url : url;
      link = 'videoparams:' + JSON.stringify({
        title: title,
        icon: icon ? icon : Plugin.path + "images/video.png",
        sources: [{ url: linkUrl }],
        no_fs_scan: true,
        no_subtitle_scan: true,
      });
    }

    if (!linkUrl) {
      var item = page.appendPassiveItem(type, '', {
        title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
        icon: icon ? icon : Plugin.path + "images/several.jpg",
      });
    } else if (description === 'metadata') {
      var item = page.appendItem(link, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
        icon: icon ? icon : Plugin.path + 'images/video.png',
        tagline: new RichText((duracion ? coloredStr(duracion, blue) : '')),
        source: new RichText(coloredStr('<b> by: ElSuacht </b>', violet)),
        description: new RichText((sinopsis ? coloredStr('Sinopsis: ', orange) + sinopsis : '')),
      });
      addOptionForAddingToMyFavorites(item, link, title, icon, '', duracion, '', '', sinopsis, type);
    } else {
      var item = page.appendItem(link, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
        icon: icon ? icon : Plugin.path + 'images/video.png',
        source: new RichText(coloredStr('<b> by: ElSuacht </b>', violet)),
        description: new RichText((linkUrl ? coloredStr('Link: ', orange) + linkUrl : '') + 
      (icon ? '\n' + coloredStr('Imagen URL: ', orange) + icon : '') || 'Vacío'),
      });
      addOptionForAddingToMyFavorites(item, link, title, icon, '', duracion, '', '', sinopsis, type);
    }
  } else {
    var item = page.appendItem(route, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
        icon: icon,
        tagline: duracion,
        source: new RichText(coloredStr('<b> by: ElSuacht </b>', violet)),
        rating: url,
        description: description
    });
    return item;
  }
}

function showM3U(page, pl) {
  var num = 0;
  for (var i in groups) {
    page.appendItem('', 'separator', { title: '', });
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>' + groups[i] + '</i> ==★== </b>', orange)),
    });

    var pos = 0;
    for (var j in m3uItems) {
      if (m3uItems[j].group === groups[i]) {
        if (pos < 4) {
          addItem(page, m3uItems[j].url, m3uItems[j].title, m3uItems[j].logo, '', m3uItems[j].duracion, m3uItems[j].sinopsis, '');
        }

        if (groups[i] && pos === 4) {
          var route = 'listM3u:' + encodeURIComponent(pl) + ':groupM3u:' + groups[i];
          addItem(page, '', 'Mas de ' + groups[i], m3uItems[j].logo, '', '', '', route);
          break;
        }
        pos++;
      }
    }
    num++;
  }

  for (var i in m3uItems) {
    if (m3uItems[i].group) {
      continue;
    }
    var extension = m3uItems[i].url.split('.').pop().toUpperCase();
    var itemLogo = m3uItems[i].logo || Plugin.path + "images/several.jpg";
    var link = encodeURIComponent(m3uItems[i].url);
    var route = 'listM3u:' + link + ':listM3u:' + m3uItems[i].title;

    if (isPlaylist(m3uItems[i].url) || (m3uItems[i].url == m3uItems[i].title)) {
      var item = addItem(page, '', m3uItems[i].title, itemLogo, '', '', '', route);
      addOptionForAddingToMyFavorites(item, route, m3uItems[i].title, itemLogo, '', '', '', '', '', 'm3u');
      num++;
    } else {
      addItem(page, m3uItems[i].url, m3uItems[i].title, itemLogo, '', '', '', '');
      num++;
    }
    page.metadata.title = 'Agregando Items ' + num + ' de ' + m3uItems.length;
  }
}

function contentOnDynamicPagesM3u(page, title, route, pl) {
  setPageHeader(page, decodeURIComponent(title));
  
  if (route === 'listM3u' || route === 'groupM3u') {
    if (service.disableM3uOp && route === 'listM3u') {
      m3uLinks = pl;
      pl = scrapper + 'm3uOp?codigo=' + code + '&m3u=' + pl + '&query=m3u&page=' + numerPages;
    }

    page.appendItem("listM3u:" + m3uLinks + ':searchM3u:', "search", {
        title: "Buscar en M3U...",
    });
    page.appendItem('', 'separator', {
      title: '',
    });
  } else {  
    if (service.disableM3uOp) {
      if (theLastSearch !== title) {
        numerPages = 1;
      }

      pl = scrapper + 'm3uOp?codigo=' + code + '&m3u=' + m3uLinks + '&query=' + encodeURIComponent(title) + '&page=' + numerPages;

      theLastSearch = title;
    } else {
      pl = scrapper + 'm3uOp?codigo=' + code + '&m3u=' + theLastList + '&query=' + encodeURIComponent(title) + '&page=all';
    }
  }

  try {
    if (theLastList != pl) {
      readAndParseM3U(page, pl);
    }
  } catch (error) {
    page.error('No se pudo obtener datos.');
    return;
  }

  if (!m3uItems || m3uItems.length === 0) {
    page.error('No se encontraron resultados');
    return;
  }
  
  if (route === 'listM3u' || route === 'searchM3u') {
    showM3U(page, decodeURIComponent(pl));
  } else {
    for (var i in m3uItems) {
      if (decodeURIComponent(title) != m3uItems[i].group) {
        continue;
      }
      addItem(page, m3uItems[i].url, m3uItems[i].title, m3uItems[i].logo, '', m3uItems[i].duracion, m3uItems[i].sinopsis, '');
    }
  }

  if (service.disableM3uOp) {
    passPages(page, m3uItems.length, 'listM3u:' + m3uLinks + ':' + route + ':' + title, title);
  } else {
    page.metadata.title = new RichText(decodeURIComponent(title));
  }

  page.loading = false;
}

function passPages(page, num, redirect, title) {
  if (numerPages > 1) {
    page.options.createAction('gotoPageBackJson', 'Regresar Página', function() {
      numerPages--;
      page.redirect(redirect);
    });
  } 

  if (num === 100) {
    popup.notify("Puedes visitar la siguiente página, desde el menu lateral.  (Triangulo)" ,5);
    page.options.createAction('gotoPageNextJson', 'Siguiente Página', function() {
      numerPages++;
      page.redirect(redirect);
    });
  } else if (num < 100) {
    popup.notify("Resultados encontrados " + num, 5);
  } else if (num === 0) {
    page.error("No se encontraron resultados.");
  }

  page.metadata.title = new RichText((numerPages === 1 ? '' : 'Pag ' + numerPages + ' - ') + title);
}

// IPTV JSON

function mainIptv(page) {
  setPageHeader(page, 'Buscando Servidores...');

  var arg;
  if (!service.disableAdultos) {
    arg = 'General';
  } else {
    arg = 'Adultos';
  }  

  page.options.createAction('gotoInicio', 'Inicio', function() {
    page.redirect(plugin.id + ':start');
  });
  page.appendItem("iptvJson::", "search", {
      title: "Buscar canales...",
  });

  if (service.selectCountry == 'undefined') {
    popup.notify("Elige un Pais desde los Ajustes de Movian, baja a la Opcion", 7);
    popup.notify("Applications and Installed Plugins y Entra a PlayStr3am", 7);
  } 

  var response;
  try {
      response = http.request(scrapper + 'iptv?code=' + code + '&json=' + arg + '&query=' + service.selectCountry, {
          headers: {
              'User-Agent': "Mozilla/5.0",
          },
      });
  } catch (err) {
      page.error('No se pudo obtener datos');
      page.loading = false;
      return;
  }

  jsonIptv = JSON.parse(response);

  var secciones = jsonIptv['IPTV'];
  var seccion = Object.keys(secciones);

  for (var i = 0; i < seccion.length; i++) {
      var seccionTitle = seccion[i];
 
      page.appendItem('', 'separator', { title: '', });
      page.appendItem('', 'separator', {
        title: new RichText(coloredStr('<b>==★== <i>' + seccionTitle + '</i> ==★== </b>', orange)),
      });

      var canales = jsonIptv['IPTV'][seccionTitle];
      var canal = Object.keys(canales);

      var pos = 0;
      for (var j = 0; j < canal.length; j++) {
        var canalTitle = canal[j];
        var canalData = canales[canalTitle];

        if (pos < 4) {
          addItem(page, canalData.link, canalTitle, canalData.imagen, 'metadata', '', '', '');
        }
        
        if (pos === 4) {
          addItem(page, '', 'Mas de ' + seccionTitle, canalData.imagen, '', '', '', 'iptvJson:' + seccionTitle + ':');
          break;
        }
        pos++;
      }
  }

  page.metadata.title = "IPTV";
  page.loading = false;
}

function showIptv(page, seccion, query) {
  if (query === '') {
    setPageHeader(page, 'IPTV - ' + seccion);

    var canales = jsonIptv['IPTV'][seccion];
    var canal = Object.keys(canales);

    for (var i = 0; i < canal.length; i++) {
      var canalTitle = canal[i];
      var canalData = canales[canalTitle];
      addItem(page, canalData.link, canalTitle, canalData.imagen, 'metadata', '', '', '');
    }
  } else {
    setPageHeader(page, 'IPTV - ' + query);

    var response;
    try {
        response = http.request(scrapper + 'iptv?code=' + code + '&json=Search&query=' + encodeURIComponent(query), {
            headers: {
                'User-Agent': "Mozilla/5.0",
            },
        });
    } catch (err) {
        page.error('No se pudo obtener datos');
        page.loading = false;
        return;
    }

    var jsonIptvSearch = JSON.parse(response);

    var secciones = jsonIptvSearch[query];
    var seccion = Object.keys(secciones);

    for (var i = 0; i < seccion.length; i++) {
        var seccionTitle = seccion[i];
        var canales = jsonIptvSearch[query][seccionTitle];
        var canal = Object.keys(canales);

        for (var j = 0; j < canal.length; j++) {
          var canalTitle = canal[j];
          var canalData = canales[canalTitle];
          addItem(page, canalData.link, canalTitle, canalData.imagen, 'metadata', '', '', '');
        }
    }

    addSearchToHistory(page, query, 'iptv');
  }
  page.loading = false;
}

// Peliculas JSON

function jsonParseSearch(page, query) {
  var header;
  if (numerPages === 1) {
    header = 'Buscando ' + query + '...';
  } else {
    header = 'Cambiando Página...';
  }
  setPageHeader(page, header);
  page.loading = true;
  var num = 0;

  if (theLastSearch !== query) {
    numerPages = 1;
  }
  var response;
  try {
    response = http.request(scrapper + 'json?codigo=' + code + '&query=' + encodeURIComponent(query) + '&page=' + numerPages);
  } catch (err) {
    page.error("No se pudo obtener datos.");
    page.loading = false;
    return;
  }

  var data = JSON.parse(response);
  for (var movieTitle in data.items) {
    if (data.items.hasOwnProperty(movieTitle)) {
      var movie = data.items[movieTitle];
      var image = movie.still_path || Plugin.path + 'images/video.png';
      var route = 'jsonContent:' + movieTitle;
      var genresText = movie.genres ? coloredStr('Género: ', violet) + movie.genres : '';
      var castText = movie.cast ? '\n' + coloredStr('Cast: ', blue) + movie.cast : '';
      var similarText = movie.similar ? '\n' + coloredStr('Recomendado: ', green) + movie.similar : '';
      var sinopsisText = movie.overview ? '\n' + coloredStr('Sinopsis: ', orange) + movie.overview : '';
      var description = new RichText(genresText + castText + similarText + sinopsisText);
      var item = addItem(page, '', movieTitle, image[0], description, '', '', route);
      addOptionForAddingToMyFavorites(item, route, movieTitle, image, castText, '', genresText, similarText, sinopsisText, 'json');
      num++;
    }
    page.metadata.title = 'Agregando Items ' + num + ' de ' + Object.keys(data.items).length;
  }

  theLastSearch = query;
  if(numerPages === 1) {
    addSearchToHistory(page, query, 'movie');
  }

  passPages(page, num, 'searchJson:' + query, query);
  page.loading = false;
}

function jsonParseContent(page, title) {
  setPageHeader(page, 'Buscando Informacion: ' + title + '...');
  page.model.contents = 'list';
  var response;
  try {
    response = http.request(scrapper + 'json?codigo=' + code + '&query=' + encodeURIComponent(title) + '&page=JSON');
  } catch (err) {
    page.error("No se pudo obtener los datos.");
    page.loading = false;
    return;
  }

  var data = JSON.parse(response);
  var movie = data.items[title];
  if (!movie) {
    page.error("Película no encontrada.");
    page.loading = false;
    return;
  }

  var movieBackground = movie.background || Plugin.path + 'images/background.jpg';
  var image = movie.still_path || Plugin.path + 'images/video.png';
  var genres = movie.genres ? movie.genres : [];
  var cast = movie.cast ? movie.cast : [];
  var castImage = movie.castImage ? movie.castImage : [];
  var castInfo = movie.castInfo ? movie.castInfo : [];
  var similar = movie.similar ? movie.similar : [];
  var sinopsis = movie.overview || "Sin descripción disponible.";
  var duracion = movie.duration + ' Minutos';
  var rating = movie.rating;
  var mediaType = movie.media_type;
  var type = 'video';
  background = movieBackground;
  page.metadata.icon = image;

  if (background != '') {
    page.metadata.background = background;
  }

  var premiumLinks = data.items[title];
  var links = premiumLinks.Links;
  var linkKeys = Object.keys(links);

  page.appendPassiveItem(type, "", {
    title: new RichText(coloredStr('<b>' + 'Sinopsis' + '</b>', orange)),
    icon: image,
    rating: rating,
    source: new RichText(coloredStr('<b> by: ElSuacht </b>', violet)),
    description: new RichText((sinopsis ? sinopsis : '')),
  });

  var servs = ''
  if (mediaType == 'movie') {
    servs = 'Servidores';
  } else if (mediaType == 'tv') {
    servs = 'Temporadas';
  }

  page.appendItem('', 'separator', {
    title: new RichText(coloredStr('<b>==★== <i>' + servs + '</i> ==★== </b>', orange)),
  });

  for (var i = 0; i < linkKeys.length; i++) {
    var linkName = linkKeys[i];
    var linkUrl = links[linkName];
    if (mediaType === 'movie' || mediaType === null) {
      addItem(page, linkUrl, linkName, image, 'metadata', duracion, '', '');
    } else if (mediaType === 'tv') {
      jsonSeasonData(page, linkUrl);
    }
  }

  type = 'video';

  if (genres.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Géneros</i> ==★== </b>', violet)),
    });
    for (var i = 0; i < genres.length; i++) {
      page.appendItem('searchJson:' + genres[i], type, {
        title: new RichText(coloredStr('<b>' + genres[i] + '</b>', violet)),
        icon: Plugin.path + "images/genres/" + encodeURIComponent(genres[i]) + ".png",
        source: new RichText(coloredStr('<b> by: ElSuacht </b>', violet)),
      });
    }
  }

  if (cast.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Reparto</i> ==★== </b>', blue)),
    });
    for (var i = 0; i < cast.length; i++) {
      var route = 'searchJson:' + cast[i];
      var item = page.appendItem(route, type, {
        title: new RichText(coloredStr('<b>' + cast[i] + '</b>', blue)),
        icon: castImage[i],
        genre: new RichText(coloredStr('<b>' + 'Caracterizando: ' + '</b>', blue) + castInfo[i]),
        source: new RichText(coloredStr('<b> by: ElSuacht </b>', violet)),
      });
      addOptionForAddingToMyFavorites(item, route, cast[i], castImage[i], castInfo[i], '', '', '', '', 'history');
    }
  }

  if (similar.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Recomendado</i> ==★== </b>', green)),
    });

    var num = 0;
    for (var i = 0; i < similar.length; i++) {
      var similarItem = similar[i];
      var similarTitle = similarItem.name || coloredStr("Sin resultados en PlayStr3am", red);
      var similarGenres = similarItem.genres ? similarItem.genres.join(", ") : coloredStr("Sin resultados en PlayStr3am", red);
      var similarCast = similarItem.cast ? similarItem.cast.join(", ") : coloredStr("Sin resultados en PlayStr3am", red);
      var similarOverview = similarItem.overview || coloredStr("Sin resultados en PlayStr3am", red);
      var similarImage = similarItem.still_path || Plugin.path + "images/video.png";
      var route = 'jsonContent:' + similarTitle;

      var item = page.appendItem(route, type, {
        title: new RichText(coloredStr('<b>' + similarTitle + '</b>', green)),
        icon: similarImage,
        genre: new RichText((similarGenres ? coloredStr('Genero: ', green) +similarGenres : '') +
          (similarCast ? '\n' + coloredStr('Cast: ', green) + similarCast : '')),
        rating: similarItem.rating,
        tagline: new RichText((similarItem.duration ? coloredStr(similarItem.duration + ' Minutos', green) : '')),
        source: new RichText(coloredStr('<b> by: ElSuacht </b>', violet)),
        description: new RichText((similarOverview ? '\n' + coloredStr('Sinopsis: ', green) + similarOverview : '')),
      });
      addOptionForAddingToMyFavorites(item, route, similarTitle, similarImage, similarCast, '', similarGenres, 'json', similarOverview, 'json');
      num++;
    }
  }
  page.metadata.title = title;
  page.loading = false;
}

// Series JSON

function jsonSeasonData(page, pl) {
    var response;
    page.metadata.title = "Cargando Temporadas...";
    
    try {
        response = http.request('http://playstr3am.myartsonline.com/' + pl, {
            headers: {
                'User-Agent': "Mozilla/5.0",
            },
        });
    } catch (err) {
        //page.error("No se pudo obtener datos.");
        //page.loading = false;
        //return;
    }

    jsonData = JSON.parse(response);

    var seriesNames = jsonData['Series'];
    var seriesName = Object.keys(seriesNames);
    if (seriesName.length === 0) {
        page.error("No se encontraron series en el JSON.");
        page.loading = false;
        return;
    }

    var seasons = jsonData['Series'][seriesName];
    var temporadas = Object.keys(seasons);

    for (var i = 0; i < temporadas.length; i++) {
        var seasonTitle = temporadas[i];
        var seasonData = seasons[seasonTitle];
        var sinopsis = seasonData.overview ? '\n' + coloredStr('Sinopsis: ', orange) + seasonData.overview : '';
        var image = seasonData.image_path;
        var description = new RichText(sinopsis);
        var route = 'seasonsJson:' + seriesName + ':' + seasonTitle + ':';
        var item = addItem(page, seasonData.rating, seasonTitle, image, description, '', '', route);
        addOptionForAddingToMyFavorites(item, route, seriesName + ' - ' + seasonTitle, image, '', '', '', '', '', 'seasons');
    }
    page.loading = false;
}

function jsonEpisodesData(page, seriesName, seasonTitle, episodeTitle) {
    if (episodeTitle === '') {
      setPageHeader(page, seasonTitle);
      page.model.contents = 'list';
      if (background != '') {
        page.metadata.background = background;
      }

      if (!jsonData['Series'].hasOwnProperty(seriesName) || !jsonData['Series'][seriesName].hasOwnProperty(seasonTitle)) {
          page.error("No se encontraron episodios para " + seriesName + " - " + seasonTitle);
          page.loading = false;
          return;
      }

      var episodes = jsonData['Series'][seriesName][seasonTitle];
      var episodeNumbers = Object.keys(episodes);

      for (var i = 0; i < episodeNumbers.length; i++) {
          var episodeTitle = episodeNumbers[i];
          var episodeData = episodes[episodeTitle];
          var duracion = new RichText(episodeData.duracion ? coloredStr(episodeData.duracion, blue) : '');
          var sinopsis = episodeData.sinopsis ? '\n' + coloredStr('Sinopsis: ', orange) + episodeData.sinopsis : '';
          var description = new RichText(sinopsis);
          var route = 'seasonsJson:' + seriesName + ':' + seasonTitle + ':' + episodeTitle;
          if (episodeTitle != 'overview' && episodeTitle != 'image_path' && episodeTitle != 'rating') {
            var item = addItem(page, episodeData.rating, episodeTitle, episodeData.imagen, description, duracion, '', route);
            addOptionForAddingToMyFavorites(item, route, seriesName + ' - ' + seasonTitle + ' - ' + episodeTitle, episodeData.imagen, '', '', '', '', '', 'seasons');
          }
      }
    } else {
      setPageHeader(page, episodeTitle);
      page.model.contents = 'list';
      if (background != '') {
        page.metadata.background = background;
      }

      if (!jsonData['Series'].hasOwnProperty(seriesName) || !jsonData['Series'][seriesName].hasOwnProperty(seasonTitle) || !jsonData['Series'][seriesName][seasonTitle].hasOwnProperty(episodeTitle)) {
          page.error("No se encontraron enlaces para " + episodeTitle);
          page.loading = false;
          return;
      }

      var episodeData = jsonData['Series'][seriesName][seasonTitle][episodeTitle];

      if (!episodeData.hasOwnProperty("links")) {
          page.error("Este episodio no tiene enlaces disponibles.");
          page.loading = false;
          return;
      }

      var links = episodeData.links;
      var linkKeys = Object.keys(links);

      for (var i = 0; i < linkKeys.length; i++) {
          var linkName = linkKeys[i];
          var linkUrl = links[linkName];

          addItem(page, linkUrl, linkName, episodeData.imagen, 'metadata', episodeData.duracion, episodeData.sinopsis, '');
      }
    }
    page.loading = false;
}

// Internet Archive

function addMediaItem(page, media) {
  var icon = "https://archive.org/services/img/" + media.identifier;
  var route = "internetArchiveFiles:" + media.identifier + ':';
  var item = addItem(page, '', media.title, icon, '', '', '', route);
  addOptionForAddingToMyFavorites(item, route, media.title, icon, '', '', '', '', '', 'archive');
  //item.icon = icon;
  page.entries++;
}

function addDiscoverSection(page) {
  var offset = 1;
  var count = 10;

  function loader() {
    if (!offset) return false;
    page.loading = true;

    var args = {
      q: 'mediatype:(movies OR audio)',
      fl: ["identifier", "title", "mediatype"],
      sort: ["downloads desc"],
      rows: count,
      page: offset,
      output: "json"
    };

    try {
      var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
        args: args
      }));
    } catch(err) {
      page.error('No se pudieron obtener datos de Internet Archive.');
      return;
    }

    if (offset == 1) {
      page.appendItem("", "separator", {
        title: ''
      });
    }

    page.loading = false;
    for (var i in c.response.docs) {
      var item = c.response.docs[i];
      if (item.mediatype === 'movies' || item.mediatype === 'audio') {
        addMediaItem(page, item);
        if (page.entries >= count) return offset = false;
      }
    }

    offset++;
    return c.response.docs && c.response.docs.length > 0;
  }
  loader();
  page.paginator = loader;
  page.loading = false;
}

function showFilesInterntArchive(page, id, query, count) {
  if (query === '') {
    setPageHeader(page, id);
    page.model.contents = 'list';
    var encodedId = encodeURIComponent(id);
    var listingImage = "https://archive.org/services/img/" + encodedId;
    page.metadata.background = listingImage;
    var itemUrl = 'https://archive.org/metadata/' + encodedId;

    var response;
    try {
      response = http.request(itemUrl);
    } catch (err) {
      page.error("No se pudieron recuperar los metadatos del elemento.");
      page.loading = false;
      return;
    }

    var metadata = JSON.parse(response);
    if (!metadata || !metadata.files || metadata.files.length === 0) {
      page.error('No se han encontrado archivos en el elemento seleccionado.');
      page.loading = false;
      return;
    }

    var mediaFiles = metadata.files.filter(function(file) {
      return /\.(mp4|avi|3gp|mp3|ogg|m4a)$/.test(file.name);
    });

    if (mediaFiles.length === 0) {
      page.error('No se han encontrado archivos en el elemento seleccionado.');
      page.loading = false;
      return;
    }

    var media = {
      identifier: id,
      title: metadata.metadata.title || "Unknown Title",
      mediatype: metadata.metadata.mediatype || "Unknown Type",
      icon: "https://archive.org/services/img/" + id
    };

    mediaFiles.forEach(function(file) {
      var mediaUrl = 'https://archive.org/download/' + encodedId + '/' + encodeURIComponent(file.name);
      addItem(page, mediaUrl, file.name, listingImage, '', '', '', '');
    });

    popup.notify("Algunos archivos pueden tener restricciones.", 5);
  } else if (id === '') {
    setPageHeader(page, "Buscando resultados para: " + query);
    var offset = 1;
    page.entries = 0;

    function loader() {
      if (!offset) return false;
      page.loading = true;

      var args = {
        q: query,
        fl: ["identifier", "title", "mediatype"],
        sort: ["downloads desc"],
        rows: count ? count : 50,
        page: offset,
        output: "json"
      };

      try {
        var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
          args: args
        }));
      } catch(err) {
        page.error('No se pudieron obtener datos de Internet Archive.');
        return;
      }

      page.loading = false;
      if (offset == 1 && page.metadata && c.response.numFound)
        page.metadata.title = query;
      page.model.contents = 'grid';
      for (var i in c.response.docs) {
        var item = c.response.docs[i];
        if (item.mediatype === 'movies' || item.mediatype === 'audio') {
          addMediaItem(page, item);
          if (count && page.entries >= count) return offset = false;
        }
      }
      offset++;
      return c.response.docs && c.response.docs.length > 0;
    }
    loader();
    page.paginator = loader;
    addSearchToHistory(page, query, 'archive');
  }

  page.loading = false;
}

function mainAndPopularInterntArchive(page, route) {
  if (route === "") {
    setPageHeader(page, "Internet Archive");

    page.options.createAction('gotoInicio', 'Inicio', function() {
      page.redirect(plugin.id + ':start');
    });
    page.appendItem("internetArchiveFiles::", 'search', {
      title: 'Busca en Archive.org'
    });
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Más Populares</i> ==★== </b>', orange)),
    });
  
    addDiscoverSection(page);
  
    page.options.createAction('gotoInternetArchive', 'Populares en Archive', function() {
      page.redirect(plugin.id + ':internetArchive:popular');
    });
   
    popup.notify("¡Visita Archive.org y dona si puedes!", 7);
  } else if (route === 'popular') {
    setPageHeader(page, "Populares en Archive");

    var args = {
      q: 'mediatype:movies',
      fl: ["identifier", "title", "mediatype"],
      sort: ["downloads desc"],
      rows: 100,
      output: "json"
    };

    try {
      var c = JSON.parse(http.request("https://archive.org/advancedsearch.php", {
        args: args
      }));
    } catch(err) {
      page.error('No se pudieron obtener datos de Internet Archive.');
      return;
    }

    for (var i in c.response.docs) {
      var video = c.response.docs[i];
      if (video.mediatype === 'movies') {
        addMediaItem(page, video);
      }
    }
  }
  page.loading = false;
}

// Paginas Principales

page.Route(plugin.id + ':start', function(page) {
  mainPage(page);
  var backdropURL = 'https://image.tmdb.org/t/p/w1280/gc8PfyTqzqltKPW3X0cIVUGmagz.jpg';

  page.appendItem(Plugin.path + ':favoritesandRecord:favorites', 'video', { 
      title: 'TEST',
      icon: backdropURL,
      genre: 'ACION',
      rating: 10,
      description: 'K'
  });
});

new page.Route(plugin.id + ':favoritesandRecord:(.*)', function(page, route) {
  favoriteAndPagesHistory(page, route);
});

// Paginas M3U

new page.Route('listM3u:(.*):(.*):(.*)', function(page, pl, route, title) {
  contentOnDynamicPagesM3u(page, title, route, pl);
});

// Paginas JSON

new page.Route(plugin.id + ':iptv', function(page) {
  mainIptv(page);
});

new page.Route('iptvJson:(.*):(.*)', function(page, seccion, query) {
  showIptv(page, seccion, query);
});

new page.Route('searchJson:(.*)', function(page, query) {
  jsonParseSearch(page, query);
});

new page.Route("jsonContent:(.*)", function (page, title) {
  jsonParseContent(page, title);
});

new page.Route('seasonsJson:(.*):(.*):(.*)', function(page, title, season, episode) {
  jsonEpisodesData(page, title, season, episode);
});

// Paginas Internet Archive

new page.Route(plugin.id + ":internetArchive:(.*)", function(page, route) {
  mainAndPopularInterntArchive(page, route);
});

new page.Route("internetArchiveFiles:(.*):(.*)", function(page, id, query) {
  showFilesInterntArchive(page, id, query);
});