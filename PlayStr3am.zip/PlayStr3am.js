//Variables

var page = require('showtime/page');
var service = require('showtime/service');
var settings = require('showtime/settings');
var http = require('showtime/http');
var string = require('native/string');
var popup = require('native/popup');
var io = require('native/io');
var store = require('movian/store');
var plugin = JSON.parse(Plugin.manifest);
var logo = Plugin.path + plugin.icon;
var localVersion = plugin.version;

var base = "https://playstr3am.netlify.app/";
var scrapper = base + ".netlify/functions/";
var playlist = "http://playstr3am.myartsonline.com/";
var numerPages = 1;
var tosAccepted = false;
var tos = "Este plugin se proporciona con fines educativos y de aprendizaje. El creador no se hace responsable del uso que se le dé ni del contenido reproducido, el cual puede ser de terceros. El usuario asume toda la responsabilidad legal sobre el uso del plugin, asegurándose de que no infrinja derechos de autor ni leyes locales. El creador no será responsable por daños, pérdidas o problemas legales derivados del uso del plugin. El plugin está destinado a uso personal y no debe ser modificado ni distribuido para fines comerciales sin permiso. Al utilizar este plugin, aceptas estos términos.";

var tosVerify = store.create('tosVerify');
if (!tosVerify.list) {
  tosVerify.list = '[]';
}

var favorites = store.create('favorites');
if (!favorites.list) {
  favorites.list = '[]';
}

var browser = store.create('browser');
if (!browser.list) {
  browser.list = '[]';
}

var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36';

var blue = '6699CC', orange = 'FFA500', red = 'EE0000', green = '008B45';
var m3uItems = [], groups = [], theLastList = '';

//Funciones

RichText = function(x) {
  this.str = x.toString();
};

RichText.prototype.toRichString = function(x) {
  return this.str;
};

function coloredStr(str, color) {
  return '<font color="' + color + '">' + str + '</font>';
}

function trim(s) {
  if (s) return s.replace(/(\r\n|\n|\r)/gm, '').replace(/(^\s*)|(\s*$)/gi, '').replace(/[ ]{2,}/gi, ' ').replace(/\t/g, '');
  return '';
}

function log(str) {
  if (service.debug) {
    console.log(str);
    print(str);
  }
}

function setPageHeader(page, title) {
  if (page.metadata) {
    page.metadata.title = new RichText(decodeURIComponent(title));
    page.metadata.logo = logo;
  }
  page.type = 'directory';
  page.contents = 'items';
  page.loading = false;
  page.model.contents = 'grid';
  page.metadata.icon = logo;
  if (!service.disableBackground) {
  page.metadata.background = Plugin.path + "fondo.jpg"
  }
}

function isPlaylist(pl) {
  pl = unescape(pl).toUpperCase();
  var extension = pl.split('.').pop();
  var lastPart = pl.split('/').pop();
  if (pl.substr(0, 4) == 'M3U:' || (extension == 'M3U' && pl.substr(0, 4) != 'HLS:') || lastPart == 'PLAYLIST' ||
    pl.match(/TYPE=M3U/) || pl.match(/BIT.DO/) || pl.match(/BIT.LY/) || pl.match(/GOO.GL/) ||
    pl.match(/TINYURL.COM/) || pl.match(/RAW.GITHUB/) || pl.match(/PS3.PHP?/)) {
    return 'm3u';
  }
  return false;
}

function checkupdate(page) {
  resp = http.request(base + "plugin.json").toString();
  console.log(resp);
  const latestVersion = JSON.parse(resp).version;

  if (localVersion < latestVersion) {
  page.options.createAction("update", "Actualizar PlayStr3am", function () {
    popup.notify("Actualizando, espere 10 segundos y regrese atras...",0xa );
    page.redirect(base + "PlayStr3am.zip");
  });
  }

  if (localVersion < latestVersion) {
  console.log("Version Actual: " + localVersion + ", Nueva Version Disponible: " + latestVersion);
  popup.notify("Version Actual: " + localVersion + ", Nueva Version Disponible: " + latestVersion, 5);
  popup.notify("Actualiza PlayStr3am desde el menu lateral", 0xa);
  }
}

//Configuraciones

service.create(plugin.title, plugin.id + ':start', 'PlayStr3am', true, logo);
settings.globalSettings(plugin.id, plugin.title, logo, plugin.synopsis);

settings.createDivider("Datos de Usuario:");

settings.createString('userName', 'Ingresa tu Usuario', 'Usuario', function(value) {
  service.userName = value;
});
settings.createString('userCode', 'Ingresa tu Código', '', function(value) {
  service.userCode = value;
});

settings.createDivider("Configuraciones de " + service.userName  + ":");

settings.createBool('disableHistorial', 'Ocultar Ultimas Busquedas', false, function(v) {
  service.disableHistorial = v;
});
settings.createAction('cleanBrowser', 'vacía Tu Historial', function() {
  browser.list = '[]';
  popup.notify('Tu Historial de Busqueda se ha vaciado exitosamente', 2);
});
settings.createBool('disableMyFavorites', 'Ocultar Ultimos Favoritos', false, function(v) {
  service.disableMyFavorites = v;
});
settings.createAction('cleanFavorites', 'vacía Tus Favoritos', function() {
  favorites.list = '[]';
  popup.notify('Tus Favoritos se han vaciado exitosamente', 2);
});
settings.createBool("backgroundEnabled", "Ocultar Background", false, function(v) {
  service.disableBackground = v;
});

function validarUrl(page) {
    try {
        // Verificar si el userCode está vacío
        if (!service.userCode || service.userCode.trim() === "") {
            popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'", 0xa);
            throw new Error('Tu Código Expiró, Genera uno Nuevo');
        }

        // Realizar la solicitud HTTP
        var response = http.request(playlist + "CodigosPS3.php?online=" + encodeURIComponent(service.userCode), {
            method: 'GET',
            headers: { 'User-Agent': UA }
        });

        // Validar respuesta HTTP
        if (response.status < 200 || response.status >= 300 || response.status >= 500) {
            popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'", 0xa);
            throw new Error('Tu Código Expiró, Genera uno Nuevo');
        }

        return true;
    } catch (e) {
        popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'", 0xa);
        page.error('Tu Código Expiró, Genera uno Nuevo');
        return false;
    }
}

//Favoritos 

function addOptionForAddingToMyFavorites(item, link, title, icon, cast, genres, similar, sinopsis, type) {
  item.addOptAction('Agrega \'' + title + '\' a Tus Favoritos', function() {
    var entry = JSON.stringify({
      link: encodeURIComponent(link),
      title: encodeURIComponent(title),
      icon: encodeURIComponent(icon),
      cast: encodeURIComponent(cast),
      genres: encodeURIComponent(genres),
      similar: encodeURIComponent(similar),
      sinopsis: encodeURIComponent(sinopsis),
      type: encodeURIComponent(type),
    });
    favorites.list = JSON.stringify([entry].concat(eval(favorites.list)));
    popup.notify('\'' + title + '\' a sido Agregado a Tus Favoritos.', 2);
  });
}

function addOptionForRemovingFromMyFavorites(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de Tus Favoritos?', function() {
    var list = JSON.parse(favorites.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminado de Tus Favoritos.', 2);
    list.splice(pos, 1);
    favorites.list = JSON.stringify(list);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function fill_fav(page) {
  var ruteRemoving = ':favorites';
  var list;
  try {
    list = JSON.parse(favorites.list);
  } catch (e) {
    list = [];
  }

  if (!list || list.length === 0) { 
    page.error('Aún No Tienes Favoritos');
    return;
  }

  var pos = 0;
  for (var i in list) {
    var itemmd = JSON.parse(list[i]);

    var decodedLink = decodeURIComponent(itemmd.link);
    var decodedTitle = decodeURIComponent(itemmd.title);
    var decodedIcon = itemmd.icon ? decodeURIComponent(itemmd.icon) : null;
    var decodedType = itemmd.type;
    var cast = decodeURIComponent(itemmd.cast);
    var genres = decodeURIComponent(itemmd.genres);
    var similar = decodeURIComponent(itemmd.similar);
    var sinopsis = decodeURIComponent(itemmd.sinopsis);

    var route = '';
    if (decodedType === 'm3u') {
      route = 'PlayStr3am:';
    } else if (decodedType === 'browser') {
      route = 'Resultados:';  
    } else {
      route = '';
    }

    var rutaFavoritos = route + decodedLink + ':' + decodedTitle;

    var item = page.appendItem(rutaFavoritos, 'video', {
      title: new RichText(coloredStr('<b>' + decodedTitle + '</b>', orange)),
      icon: decodedIcon,
      description: new RichText((genres ? coloredStr('Genero: ', orange) + genres : '') +
          (cast ? '\n' + coloredStr('Cast: ', orange) + cast : '') +
          (similar ? '\n' + coloredStr('Recomendado: ', orange) + similar : '') +
          (sinopsis ? '\n' + coloredStr('Sinopsis: ', orange) + sinopsis : '')),
    });

    addOptionForRemovingFromMyFavorites(page, item, decodedTitle, pos, ruteRemoving);
    pos++;
  }
}

function showUltFavorites(page) {
  var ruteRemoving = ':start';
  var list = [];
  try {
    list = JSON.parse(favorites.list || '[]');
  } catch (e) {
    popup.notify('Error al cargar los favoritos: ' + e.message, 5);
  }

  var pos = 0;
  for (var i in list) {
    if (pos >= 9) break;
    var itemmd = JSON.parse(list[i]);

    var decodedLink = decodeURIComponent(itemmd.link);
    var decodedTitle = decodeURIComponent(itemmd.title);
    var decodedIcon = itemmd.icon ? decodeURIComponent(itemmd.icon) : null;
    var decodedType = itemmd.type;
    var cast = decodeURIComponent(itemmd.cast);
    var genres = decodeURIComponent(itemmd.genres);
    var similar = decodeURIComponent(itemmd.similar);
    var sinopsis = decodeURIComponent(itemmd.sinopsis);

    var route = '';
    if (decodedType === 'm3u') {
      route = 'PlayStr3am:';
    } else if (decodedType === 'browser') {
      route = 'Resultados:';  
    } else {
      route = '';
    }

    var rutaFavoritos = route + decodedLink + ':' + decodedTitle;

    var item = page.appendItem(rutaFavoritos, 'video', {
      title: new RichText(coloredStr('<b>' + decodedTitle + '</b>', orange)),
      icon: decodedIcon,
      description: new RichText((genres ? coloredStr('Genero: ', orange) + genres : '') +
          (cast ? '\n' + coloredStr('Cast: ', orange) + cast : '') +
          (similar ? '\n' + coloredStr('Recomendado: ', orange) + similar : '') +
          (sinopsis ? '\n' + coloredStr('Sinopsis: ', orange) + sinopsis : '')),
    });

    addOptionForRemovingFromMyFavorites(page, item, decodedTitle, pos, ruteRemoving);
    pos++;
  }
}


//BUSCAR

function addOptionForRemovingFromMyBrowser(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de tu Historial?', function() {
    var browserData = JSON.parse(browser.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminada.', 2);
    browserData.splice(pos, 1);
    browser.list = JSON.stringify(browserData);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function browserItems(page, pl, query) {
    try {
        if (query && query.trim()) {
            var busqueda = encodeURIComponent(query.trim());
	    var busquedaTitle = encodeURIComponent(busqueda);
            var urlBusqueda;

            if (pl && pl.trim()) {
                var listaUrl = encodeURIComponent(decodeURIComponent(pl));
                urlBusqueda = 'local?codigo=' + service.userCode + '&lista=' + listaUrl + '&query=' + busquedaTitle;
            } else {
                urlBusqueda = 'global?codigo=' + service.userCode + '&query=' + busquedaTitle;
            }

            var entry = JSON.stringify({
                title: busqueda,
                link: urlBusqueda,
            });

            var browserData = JSON.parse(browser.list || '[]');
            browserData.unshift(entry);
            browser.list = JSON.stringify(browserData);
 
            popup.notify('Buscando ' + query + '...', 5);
            //page.redirect('Resultados:' + urlBusqueda + ':Resultados');
        } else {
            popup.notify('Búsqueda cancelada o término vacío', 5);
        }
    } catch (e) {
        popup.notify('Error al procesar la búsqueda: ' + e.message, 5);
    }
}

function showBrowser(page) {
    var ruteRemoving = ':historial';
    var browserData = [];

    try {
        browserData = JSON.parse(browser.list || '[]');
    } catch (e) {
        browserData = [];
    }

    if (!browserData || browserData.length === 0) {
        page.error('Tu historial está vacío');
        return;
    }

    var pos = 0;
    for (var i in browserData) {
        var itemmd = JSON.parse(browserData[i]);
        itemmd.link = 'Resultados:' + itemmd.link;

        var groupLogo = 'https://i.ibb.co/g64LYjh/busqueda.png';
        var decodedLink = decodeURIComponent(itemmd.link);
        var decodedTitle = decodeURIComponent(itemmd.title);
        var type = 'browser';
        var item = page.appendItem(decodedLink + ':' + decodedTitle , 'video', {
            title: new RichText(coloredStr('<b>' + decodedTitle  + '</b>', orange)),
            link: decodedLink,
            icon: groupLogo
        });

        addOptionForAddingToMyFavorites(item, decodedLink, decodedTitle, groupLogo, '', '', '', '', type);
        addOptionForRemovingFromMyBrowser(page, item, decodedTitle, pos, ruteRemoving);
        pos++;
    }
}

function showUltBrowser(page) {
  var ruteRemoving = ':start';
    var list = [];
    try {
        list = JSON.parse(browser.list || '[]');
    } catch (e) {
        popup.notify('Error al cargar los favoritos: ' + e.message, 5);
    }

    var pos = 0;
    for (var i in list) {
        if (pos >= 9) break;

        var itemmd = JSON.parse(list[i]);
        
        var decodedLink = encodeURIComponent(decodeURIComponent(itemmd.link));
        var decodedTitle = decodeURIComponent(itemmd.title);
        var decodedIcon = itemmd.icon ? decodeURIComponent(itemmd.icon) : 'https://i.ibb.co/g64LYjh/busqueda.png';
        var type = 'browser';
        var item = page.appendItem('Resultados:' + decodedLink + ':' + itemmd.title, 'video', {
            title: new RichText(coloredStr('<b>' + decodedTitle + '</b>', orange)),
            icon: decodedIcon,
            type: type,
        });

        addOptionForAddingToMyFavorites(item, decodedLink, decodedTitle, decodedIcon, '', '', '', '', type);
        addOptionForRemovingFromMyBrowser(page, item, decodedTitle, pos, ruteRemoving);
        pos++;
    }
}

//ProcesarM3U

function readAndParseM3U(page, pl, m3u) { 
  var title = page.metadata.title;
  page.loading = true;
  if (!m3u) {
    page.metadata.title = 'Buscando Opciones...';
    log('Fetching: ' + decodeURIComponent(pl));
    m3u = http.request(decodeURIComponent(pl), {
      headers: {
        'User-Agent': UA,
      },
    }).toString().split('\n');
  };
  theLastList = pl;
  m3uItems = [];
  groups = [];
  var m3uUrl = '',
    m3uTitle = '',
    m3uImage = '',
    m3uGroup = '',
    m3uCast = '',
    m3uGenres = '',
    m3uSimilar = '',
    m3uSinopsis = '';
  var line = '',
    m3uRegion = '',
    m3uEpgId = '',
    m3uHeaders = '';
  m3uUA = '';

   console.log("Elementos cargados en m3uItems:", m3uItems);

  for (var i = 0; i < m3u.length; i++) {
    page.metadata.title = 'Cargando Contenido...';
    line = m3u[i].trim();
    if (line.substr(0, 7) != '#EXTM3U' && line.indexOf(':') < 0 && line.length != 40) continue;
    line = string.entityDecode(line.replace(/[\u200B-\u200F\u202A-\u202E]/g, ''));

    switch (line.substr(0, 7)) {
      case '#EXTM3U':
        var match = line.match(/region=(.*)\b/);
        if (match) {
          m3uRegion = match[1];
        }
        break;

      case '#EXTINF':
        var match = line.match(/title="([\s\S]*?)"/);
        if (match) {
          m3uTitle = match[1].trim();
        }

        match = line.match(/group="([\s\S]*?)"/);
        if (match) {
          m3uGroup = match[1].trim();
          if (groups.indexOf(m3uGroup) < 0) {
            groups.push(m3uGroup);
          }
        }

        match = line.match(/tvg-logo=["|”]([\s\S]*?)["|”]/);
        if (match) {
          m3uImage = match[1].trim();
        }

        match = line.match(/cast="([\s\S]*?)"/);
        if (match) {
          m3uCast = match[1].trim();
        }

        match = line.match(/genero="([\s\S]*?)"/);
        if (match) {
          m3uGenres = match[1].trim();
        }

        match = line.match(/similares="([\s\S]*?)"/);
        if (match) {
          m3uSimilar = match[1].trim();
        }

        match = line.match(/sinopsis="([\s\S]*?)"/);
        if (match) {
          m3uSinopsis = match[1].trim();
        }

        m3uItems.push({
          title: m3uTitle ? m3uTitle : line,
          url: m3u[i + 1] ? m3u[i + 1].trim() : 'URL no disponible', // URL es la línea siguiente
          group: m3uGroup,
          logo: m3uImage,
          cast: m3uCast,
          genres: m3uGenres,
          similar: m3uSimilar,
          sinopsis: m3uSinopsis,
          region: m3uRegion,
        });

        m3uUrl = '', m3uTitle = '', m3uImage = '', m3uGroup = '', m3uCast = '', m3uGenres = '', m3uSimilar = '', m3uSinopsis = '';
        break;

      case '#EXTGRP':
        var match = line.match(/#EXTGRP:(.*)/);
        if (match) {
          m3uGroup = match[1].trim();
          if (groups.indexOf(m3uGroup) < 0) {
            groups.push(m3uGroup);
          }
        }
        break;

      case '#EXTVLC':
        var match = line.match(/http-(user-agent=[\s\S]*)$/);
        if (match) {
          m3uUA = match[1];
        }
        break;

      default:
        if (line[0] == '#') {
          continue; 
        }
        line = line.replace(/rtmp:\/\/\$OPT:rtmp-raw=/, '');
        if (line.indexOf(':') == -1 && line.length == 40) {
          line = 'acestream://' + line;
        }

        if (m3uImage && m3uImage.substr(0, 4) != 'http') {
          m3uImage = line.match(/^.+?[^\/:](?=[?\/]|$)/) + '/' + m3uImage;
        }

        m3uHeaders = line.match(/([\s\S]*?)\|([\s\S]*?)$/);
        m3uHeaders ? line = m3uHeaders[1] : '';
    }
  }
  console.log("Elementos cargados en m3uItems:", m3uItems);
  page.metadata.title = title;
}

function addItem(page, url, title, icon, description, cast, genres, similar, sinopsis, headers) {
  var type = 'video';
  var link = url.match(/([\s\S]*?):(.*)/);
  var linkUrl = 0;
  var playlistType = isPlaylist(url);
  if (link && playlistType) {
    link = linkUrl = playlistType + ':' + encodeURIComponent(url) + ':' + escape(title);
    type = 'video';
  } else
  if (link && !link[1].toUpperCase().match(/HTTP/) && !link[1].toUpperCase().match(/RTMP/)) {
    link = linkUrl = plugin.id + ':' + url + ':' + escape(title);
  } else {
    linkUrl = url.toUpperCase().match(/M3U8/) || url.toUpperCase().match(/\.SMIL/) ? 'hls:' + url : url;
    link = 'videoparams:' + JSON.stringify({
      title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
      icon: icon ? icon : 'https://i.ibb.co/xj573br/Carpetas.jpg',
      sources: [{
        url: linkUrl,
      }],
      no_fs_scan: true,
      no_subtitle_scan: true,
    });
  }

  if (!icon && description) {
    icon = description.match(/img src="([\s\S]*?)"/);
    if (icon) icon = icon[1];
  }
  if (!linkUrl) {
    var item = page.appendPassiveItem(type, '', {
      title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
      icon: icon ? icon : 'https://i.ibb.co/xj573br/Carpetas.jpg',
    });
  } else {
    if (headers) {
      io.httpInspectorCreate('.*' + url.replace('http://', '').replace('https://', '').split(/[/?#]/)[0].replace(/\./g, '\\.') + '.*', function(req) {
        var tmp = headers.split('|');
        for (i in tmp) {
          var header = unescape(tmp[i].replace(/\"/g, '')).match(/([\s\S]*?)=([\s\S]*?)$/);
          if (header) {
            req.setHeader(header[1], header[2]);
          }
        }
      });
    }
    var type = 'video';
    var item = page.appendItem(link, type, {
      title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
      icon: icon ? icon : 'https://i.ibb.co/Hdp8G3R/video.png',
      description: new RichText((genres ? coloredStr('Genero: ', orange) + genres : '') +
          (cast ? '\n' + coloredStr('Cast: ', orange) + cast : '') +
          (similar ? '\n' + coloredStr('Recomendado: ', orange) + similar : '') +
          (sinopsis ? '\n' + coloredStr('Sinopsis: ', orange) + sinopsis : '')),
      });
    addOptionForAddingToMyFavorites(item, link, title, icon, cast, genres, similar, sinopsis, type);
  }
}

function showM3U(page, pl) {
  var num = 0;
  for (var i in groups) {
    if (groups[i]) {
      var groupLogo = 'https://i.ibb.co/xj573br/Carpetas.jpg';
      page.appendItem('PlayStr3amGroup:' + pl + ':' + encodeURIComponent(groups[i]), 'video', {
        title: new RichText(coloredStr('<b>' + groups[i] + '</b>', orange)),
        icon: groupLogo
      });
    }
    num++;
  }

  for (var i in m3uItems) {
    if (m3uItems[i].group) {
      continue;
    }
    var extension = m3uItems[i].url.split('.').pop().toUpperCase();
    var itemLogo = m3uItems[i].logo || 'https://i.ibb.co/xj573br/Carpetas.jpg';
    if (isPlaylist(m3uItems[i].url) || (m3uItems[i].url == m3uItems[i].title)) {
      var route = 'PlayStr3am:';
      //if (m3uItems[i].url.substr(0, 4) == 'PlayStr3am:') {
      //  m3uItems[i].url = m3uItems[i].url.replace('PlayStr3am:', '');
      //}
      var link = encodeURIComponent(m3uItems[i].url);
      var title = m3uItems[i].title;
      var icon = itemLogo
      var cast = m3uItems[i].cast;
      var genres = m3uItems[i].genres;
      var similar = m3uItems[i].similar;
      var sinopsis = m3uItems[i].sinopsis;
      var type = 'm3u'
      var item = page.appendItem(route + link + ':' + title, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
        icon: icon,
        description: new RichText((genres ? coloredStr('Genero: ', orange) + genres : '') +
            (cast ? '\n' + coloredStr('Cast: ', orange) + cast : '') +
            (similar ? '\n' + coloredStr('Recomendado: ', orange) + similar : '') +
            (sinopsis ? '\n' + coloredStr('Sinopsis: ', orange) + sinopsis : '')),
      });
      addOptionForAddingToMyFavorites(item, link, title, icon, cast, genres, similar, sinopsis, type);
      num++;
    } else {
      var description = '';
      addItem(page, m3uItems[i].url, m3uItems[i].title, m3uItems[i].logo, description, m3uItems[i].cast, m3uItems[i].genres, m3uItems[i].similar, m3uItems[i].sinopsis, m3uItems[i].headers);
      epgForTitle = '';
      num++;
    }
    page.metadata.title = 'PlayStr3am';
  }

  if (num > 50) {
    popup.notify("Resultados Encontrados: " + num, 5); // Notificación visible por 5 segundos
  }

  return num;
}

//Paginas

page.Route(plugin.id + ':start', function(page) {
  setPageHeader(page, plugin.title);

  if (tosVerify.list === '[]') {
    if (popup.message(tos, true, true)) {
      tosAccepted = true;
      tosVerify.list = '[1]';
    } else {
      page.error('No puedes usar el plugin sin aceptar los Términos y Condiciones.');
      return;
    }
  }

  page.loading = true;
  numerPages = 1;
  validarUrl(page);
  checkupdate(page);
  const latestVersion = JSON.parse(resp).version;
  var historial = JSON.parse(browser.list || '[]');
  var favoritos = JSON.parse(favorites.list || '[]');
  var pl = playlist + "CodigosPS3.php?online=" + encodeURIComponent(service.userCode);
  var browsers = "global?codigo=" + service.userCode;

  try {
    readAndParseM3U(page, pl);
    page.appendItem(plugin.id + ":buscar:" + browsers + ":", "search", {
        title: "Busqueda Global...",
    });
    page.appendItem('', 'separator', {
      title: '',
    });
  } catch (error) {
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }
  showM3U(page, pl);

  if (!service.disableHistorial && historial.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Ultimas Busquedas</i> ==★== </b>', orange)),
    });

    showUltBrowser(page); 

    if (!service.disableHistorial && historial.length > 9) {
      page.appendItem(plugin.id + ":historial", "video", {
        title: new RichText(coloredStr('<b>Mirar Mas...</b>', orange)),
        icon: 'https://i.ibb.co/2n8dMTS/mas.png',
      });
    } 
  }

  if (!service.disableMyFavorites && favoritos.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Ultimos Favoritos</i> ==★== </b>', orange)),
    });

    showUltFavorites(page);  

    if (!service.disableMyFavorites && favoritos.length > 9) {
      page.appendItem(plugin.id + ":favorites", "video", {
        title: new RichText(coloredStr('<b>Mirar Mas...</b>', orange)),
        icon: 'https://i.ibb.co/2n8dMTS/mas.png'
      });    
    }
  }

  if (localVersion == latestVersion) {
    popup.notify("¡Bienvenid@, " + service.userName + "! Disfruta del Contenido.",5 );
  }

  page.loading = false;
});

new page.Route(plugin.id + ':favorites', function(page) {
  setPageHeader(page, 'Tus Favoritos');
  page.loading = true;
  validarUrl(page);
  fill_fav(page);

  page.options.createAction('cleanFavorites', 'Vacía Tus Favoritos', function() {
    favorites.list = '[]';
    popup.notify('Tus Favoritos se han vaciado exitosamente', 3);
    page.redirect(plugin.id + ':start');
  });
  popup.notify("Puedes borrar todos Tus Favoritos desde el menu lateral.", 3);
  page.loading = false;
});

new page.Route('PlayStr3amGroup:(.*):(.*)', function(page, pl, groupID) {
  setPageHeader(page, decodeURIComponent(groupID));
  page.loading = true;
  validarUrl(page);
  pl = playlist + pl;

  try {
    if (theLastList != pl) {
      readAndParseM3U(page, pl);
    }
  } catch (error) {
    popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'",0xa );
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }

  if (!m3uItems || m3uItems.length === 0) {
    popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'",0xa );
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }

  var num = 0;
  for (var i in m3uItems) {
    if (decodeURIComponent(groupID) != m3uItems[i].group) {
      continue;
    }
    addItem(page, m3uItems[i].url, m3uItems[i].title, m3uItems[i].logo, '', m3uItems[i].cast, m3uItems[i].genres, m3uItems[i].similar, m3uItems[i].sinopsis, m3uItems[i].headers);
    num++;
  }

  if (num === 0) {
    page.error('No se encontraron resultados');
  }

  page.metadata.title = decodeURIComponent(groupID);
  page.loading = false;
});

new page.Route('PlayStr3am:(.*):(.*)', function(page, pl, title) {
  setPageHeader(page, unescape(title));
  validarUrl(page);
  page.loading = true;
  page.appendItem(plugin.id + ":buscar:" + encodeURIComponent(pl) + ":", "search", {
      title: "Busca en esta lista...",
  });
  page.appendItem('', 'separator', {
    title: '',
  });
  var m3u = playlist + pl;

  try {
    readAndParseM3U(page, m3u);
  } catch (error) {
    popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'",0xa );
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }

  if (!m3uItems || m3uItems.length === 0) {
    page.error('No se encontraron resultados');
    return;
  }

  page.metadata.title = new RichText(decodeURIComponent(title));
  showM3U(page, pl);
  page.loading = false;
});

new page.Route(plugin.id + ":buscar:(.*)?:(.*)?", function (page, pl, query) {
    console.log("Consulta recibida:", query);
    setPageHeader(page, "Busqueda: " + query);
    page.loading = true;
    validarUrl(page);
    browserItems(page, '', query);

    var valuePages = "&page=" + numerPages;
    var m3u = scrapper + pl + "&query=" + query + valuePages;

    try {
      readAndParseM3U(page, m3u);
    } catch (error) {
      popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'",0xa );
      page.error('Tu Código Expiró, Genera uno Nuevo');
      return;
    }

    if (!m3uItems || m3uItems.length === 0) {
      page.error('No se encontraron resultados');
      return;
    }

    page.metadata.title = new RichText(decodeURIComponent(title));
    showM3U(page, pl);

    if (m3uItems.length === 499) {
      numerPages++;
      page.appendItem('Resultados:' + pl + ':Paginas', "video", {
        title: new RichText(coloredStr('<b>Siguiente Pagina</b>', orange)),
        icon: 'https://i.ibb.co/sqjhx5C/next.png',
      });
    }
    page.loading = false;
});

new page.Route(plugin.id + ":historial", function(page) {
    setPageHeader(page, "Historial de Busqueda");
    page.loading = true;
    validarUrl(page);
    showBrowser(page);

    page.options.createAction('cleanRecord', 'Vacía Tu Historial', function() {
      browser.list = '[]';
      popup.notify('Tu Historial de Busqueda se ha vaciado exitosamente', 3);
      page.redirect(plugin.id + ':start');
    });
    popup.notify("Puedes borrar todo Tu Historial desde el menu lateral.", 3);
    page.loading = false;
});

new page.Route('Resultados:(.*):(.*)', function(page, pl, title) {
  setPageHeader(page, unescape(title));
  validarUrl(page);
  page.loading = true;
  var valuePages = "&page=" + numerPages;
  var m3u = scrapper + pl + valuePages;

  try {
    readAndParseM3U(page, m3u);
  } catch (error) {
    popup.notify("Visita \'https://playstr3am.netlify.app/Generador.html\'",0xa );
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }

  if (!m3uItems || m3uItems.length === 0) {
    page.error('No se encontraron resultados');
    return;
  }

  page.metadata.title = new RichText(decodeURIComponent(title));
  showM3U(page, pl);

  if (m3uItems.length === 499) {
    numerPages++;
    page.appendItem('Resultados:' + pl + ':Paginas', "video", {
      title: new RichText(coloredStr('<b>Siguiente Pagina</b>', orange)),
      icon: 'https://i.ibb.co/sqjhx5C/next.png',
    });
  }

  page.loading = false;
});