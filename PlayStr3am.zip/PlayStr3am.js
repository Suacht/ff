//Variables

var page = require('showtime/page');
var service = require('showtime/service');
var settings = require('showtime/settings');
var http = require('showtime/http');
var string = require('native/string');
var popup = require('native/popup');
var io = require('native/io');
var store = require('movian/store');
var plugin = JSON.parse(Plugin.manifest);
var logo = Plugin.path + plugin.icon;
var localVersion = plugin.version;
var base = "https://playstr3am.netlify.app/";
var scraper = base + ".netlify/functions/";
var DeanEdwardsUnpacker = require('./utils/Dean-Edwards-Unpacker').unpacker;

var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36';

var blue = '6699CC', orange = 'FFA500', red = 'EE0000', green = '008B45';
var m3uItems = [], groups = [], theLastList = '';

var favorites = store.create('favorites');
if (!favorites.list) {
  favorites.list = '[]';
}

var browser = store.create('browser');
if (!browser.list) {
  browser.list = '[]';
}

//Funciones

RichText = function(x) {
  this.str = x.toString();
};

RichText.prototype.toRichString = function(x) {
  return this.str;
};

function coloredStr(str, color) {
  return '<font color="' + color + '">' + str + '</font>';
}

function trim(s) {
  if (s) return s.replace(/(\r\n|\n|\r)/gm, '').replace(/(^\s*)|(\s*$)/gi, '').replace(/[ ]{2,}/gi, ' ').replace(/\t/g, '');
  return '';
}

function log(str) {
  if (service.debug) {
    console.log(str);
    print(str);
  }
}

function setPageHeader(page, title) {
  if (page.metadata) {
    page.metadata.title = new RichText(decodeURIComponent(title));
    page.metadata.logo = logo;
  }
  page.type = 'directory';
  page.contents = 'items';
  page.loading = false;
  page.model.contents = 'grid';
  page.metadata.icon = logo;
  if (!service.disableBackground) {
  page.metadata.background = Plugin.path + "fondo.jpg"
  }
}

function isPlaylist(pl) {
  pl = unescape(pl).toUpperCase();
  var extension = pl.split('.').pop();
  var lastPart = pl.split('/').pop();
  if (pl.substr(0, 4) == 'M3U:' || (extension == 'M3U' && pl.substr(0, 4) != 'HLS:') || lastPart == 'PLAYLIST' ||
    pl.match(/TYPE=M3U/) || pl.match(/BIT.DO/) || pl.match(/BIT.LY/) || pl.match(/GOO.GL/) ||
    pl.match(/TINYURL.COM/) || pl.match(/RAW.GITHUB/) || pl.match(/DL.DROPBOX.COM/) || pl.match(/PLAYSTR3AM.NETLIFY.APP/)) {
    return 'm3u';
  }
  return false;
}

function checkupdate(page) {
  page.options.createAction("update", "Actualizar PlayStr3am", function () {
    popup.notify("Actualizando, espere 10 segundos y regrese atras...",0xa );
    page.redirect(base + "PlayStr3am.zip");
  });

  resp = http.request(base + "plugin.json").toString();
  console.log(resp);
  const latestVersion = JSON.parse(resp).version;

  if (localVersion < latestVersion) {
  console.log("Version Actual: " + localVersion + ", Nueva Version Disponible: " + latestVersion);
  popup.notify("Version Actual: " + localVersion + ", Nueva Version Disponible: " + latestVersion, 3);
  }
}

function validarUrl(page) {
    try {
        var response = http.request(scraper + "code?codigo=" + encodeURIComponent(service.userCode), {
            method: 'GET',
            headers: { 'User-Agent': UA }
        });

        if (response.status < 200 || response.status >= 300) {
            throw new Error('Tu Código Expiró, Genera uno Nuevo');
        }

        if (response.status >= 500) {
            throw new Error('Tu Código Expiró, Genera uno Nuevo');
        }

        return true;
    } catch (e) {
        page.error('Tu Código Expiró, Genera uno Nuevo');
        return false;
    }
}

//Configuraciones

service.create(plugin.title, plugin.id + ':start', 'PlayStr3am', true, logo);
settings.globalSettings(plugin.id, plugin.title, logo, plugin.synopsis);

settings.createDivider("Datos de " + service.userName + ":");

settings.createString('userName', 'Ingresa tu Usuario', 'Usuario', function(value) {
  service.userName = value;
});
settings.createString('userCode', 'Ingresa tu Código', 'Ejemplo...', function(value) {
  service.userCode = value;
});

settings.createDivider("Configuraciones de " + service.userName  + ":");

settings.createBool('disableHistorial', 'Ocultar Ultimas Busquedas', false, function(v) {
  service.disableHistorial = v;
});
settings.createAction('cleanBrowser', 'vacía Tu Historial', function() {
  browser.list = '[]';
  popup.notify('Tu Historial de Busqueda se ha vaciado exitosamente', 2);
});
settings.createBool('disableMyFavorites', 'Ocultar Ultimos Favoritos', false, function(v) {
  service.disableMyFavorites = v;
});
settings.createAction('cleanFavorites', 'vacía Tus Favoritos', function() {
  favorites.list = '[]';
  popup.notify('Tus Favoritos se han vaciado exitosamente', 2);
});
settings.createBool("backgroundEnabled", "Ocultar Background", false, function(v) {
  service.disableBackground = v;
});

//Favoritos 

function addOptionForAddingToMyFavorites(item, link, title, icon, type) {
  item.addOptAction('Agrega \'' + title + '\' a Tus Favoritos', function() {
    var entry = JSON.stringify({
      link: encodeURIComponent(link),
      title: encodeURIComponent(title),
      icon: encodeURIComponent(icon),
      type: encodeURIComponent(type),
    });
    favorites.list = JSON.stringify([entry].concat(eval(favorites.list)));
    popup.notify('\'' + title + '\' a sido Agregado a Tus Favoritos.', 2);
  });
}

function addOptionForRemovingFromMyFavorites(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de Tus Favoritos', function() {
    var list = JSON.parse(favorites.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminado de Tus Favoritos.', 2);
    list.splice(pos, 1);
    favorites.list = JSON.stringify(list);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function fill_fav(page) {
  var ruteRemoving = ':favorites';
  var list;
  try {
    list = JSON.parse(favorites.list);
  } catch (e) {
    list = [];
  }

  if (!list || list.length === 0) { 
    page.error('Aún No Tienes Favoritos');
    return;
  }

  var pos = 0;
  for (var i in list) {
    var itemmd = JSON.parse(list[i]);

    var decodedLink = decodeURIComponent(itemmd.link);
    var decodedTitle = decodeURIComponent(itemmd.title);
    var decodedIcon = itemmd.icon ? decodeURIComponent(itemmd.icon) : null;
    var decodedType = itemmd.type;

    var route = '';
    if (decodedType === 'm3u') {
      route = 'PlayStr3am:';
    } else if (decodedType === 'video') {
      route = '';  
    }

    var rutaFavoritos = route + decodedLink + ':' + decodedTitle;

    var item = page.appendItem(rutaFavoritos, 'video', {
      title: new RichText(coloredStr('<b>' + decodedTitle + '</b>', orange)),
      icon: decodedIcon,
    });

    addOptionForRemovingFromMyFavorites(page, item, decodedTitle, pos, ruteRemoving);
    pos++;
  }
}

function showUltFavorites(page) {
  var ruteRemoving = ':start';
  var list = [];
  try {
    list = JSON.parse(favorites.list || '[]');
  } catch (e) {
    popup.notify('Error al cargar los favoritos: ' + e.message, 5);
  }

  var pos = 0;
  for (var i in list) {
    if (pos >= 9) break;
    var itemmd = JSON.parse(list[i]);

    var decodedLink = decodeURIComponent(itemmd.link);
    var decodedTitle = decodeURIComponent(itemmd.title);
    var decodedIcon = itemmd.icon ? decodeURIComponent(itemmd.icon) : null;
    var decodedType = itemmd.type;

    var route = '';
    if (decodedType === 'm3u') {
      route = 'PlayStr3am:';
    } else if (decodedType === 'video') {
      route = '';  
    }

    var rutaFavoritos = route + decodedLink + ':' + decodedTitle;

    var item = page.appendItem(rutaFavoritos, 'video', {
      title: new RichText(coloredStr('<b>' + decodedTitle + '</b>', orange)),
      icon: decodedIcon,
    });

    addOptionForRemovingFromMyFavorites(page, item, decodedTitle, pos, ruteRemoving);
    pos++;
  }
}


//BUSCAR

function addOptionForRemovingFromMyBrowser(page, item, title, pos, ruteRemoving) {
  item.addOptAction('Eliminar \'' + title + '\' de tu Historial?', function() {
    var browserData = JSON.parse(browser.list || '[]');
    popup.notify('\'' + title + '\' ha sido Eliminada.', 2);
    browserData.splice(pos, 1);
    browser.list = JSON.stringify(browserData);
    page.flush();
    page.redirect(plugin.id + ruteRemoving);
  });
}

function showBrowser(page) {
    var ruteRemoving = ':historial';
    var browserData = [];

    try {
        browserData = JSON.parse(browser.list || '[]');
    } catch (e) {
        browserData = [];
    }

    if (!browserData || browserData.length === 0) {
        page.error('Tu historial está vacío');
        return;
    }

    var pos = 0;
    for (var i in browserData) {
        var itemmd = JSON.parse(browserData[i]);
        itemmd.link = 'PlayStr3am:' + itemmd.link;

        var groupLogo = 'https://i.ibb.co/g64LYjh/busqueda.png';
        var decode = decodeURIComponent(itemmd.title);
        var item = page.appendItem(itemmd.link + ':' + decode, 'video', {
            title: new RichText(coloredStr('<b>' + decode + '</b>', orange)),
            link: decodeURIComponent(itemmd.link),
            icon: groupLogo
        });

        addOptionForRemovingFromMyBrowser(page, item, decode, pos, ruteRemoving);
        pos++;
    }
}

function showUltBrowser(page) {
  var ruteRemoving = ':start';
    var list = [];
    try {
        list = JSON.parse(browser.list || '[]');
    } catch (e) {
        popup.notify('Error al cargar los favoritos: ' + e.message, 5);
    }

    var pos = 0;
    for (var i in list) {
        if (pos >= 9) break;

        var itemmd = JSON.parse(list[i]);
        
        var decodedLink = encodeURIComponent(decodeURIComponent(itemmd.link));
        var decodedTitle = decodeURIComponent(itemmd.title);
        var decodedIcon = itemmd.icon ? decodeURIComponent(itemmd.icon) : 'https://i.ibb.co/g64LYjh/busqueda.png';

        var item = page.appendItem('PlayStr3am:' + decodedLink + ':' + itemmd.title, 'video', {
            title: new RichText(coloredStr('<b>' + decodedTitle + '</b>', orange)),
            icon: decodedIcon,
        });

        addOptionForRemovingFromMyBrowser(page, item, decodedTitle, pos, ruteRemoving);
        pos++;
    }
}

//ProcesarM3U

function readAndParseM3U(page, pl, m3u) { 
  var title = page.metadata.title;
  page.loading = true;
  if (!m3u) {
    page.metadata.title = 'Buscando Opciones...';
    log('Fetching: ' + decodeURIComponent(pl));
    m3u = http.request(decodeURIComponent(pl), {
      headers: {
        'User-Agent': UA,
      },
    }).toString().split('\n');
  };
  theLastList = pl;
  m3uItems = [];
  groups = [];
  var m3uUrl = '',
    m3uTitle = '',
    m3uImage = '',
    m3uGroup = '';
  var line = '',
    m3uRegion = '',
    m3uEpgId = '',
    m3uHeaders = '';
  m3uUA = '';

   console.log("Elementos cargados en m3uItems:", m3uItems);

  for (var i = 0; i < m3u.length; i++) {
    page.metadata.title = 'Cargando Contenido...';
    line = m3u[i].trim();
    if (line.substr(0, 7) != '#EXTM3U' && line.indexOf(':') < 0 && line.length != 40) continue;
    line = string.entityDecode(line.replace(/[\u200B-\u200F\u202A-\u202E]/g, ''));

    switch (line.substr(0, 7)) {
      case '#EXTM3U':
        var match = line.match(/region=(.*)\b/);
        if (match) {
          m3uRegion = match[1];
        }
        break;

      case '#EXTINF':
        var match = line.match(/#EXTINF:.*,(.*)/);
        if (match) {
          m3uTitle = match[1].trim();
        }

        match = line.match(/group-title="([\s\S]*?)"/);
        if (match) {
          m3uGroup = match[1].trim();
          if (groups.indexOf(m3uGroup) < 0) {
            groups.push(m3uGroup);
          }
        }

        match = line.match(/tvg-logo=["|”]([\s\S]*?)["|”]/);
        if (match) {
          m3uImage = match[1].trim();
        }

        m3uItems.push({
          title: m3uTitle ? m3uTitle : line,
          url: m3u[i + 1] ? m3u[i + 1].trim() : 'URL no disponible', // URL es la línea siguiente
          group: m3uGroup,
          logo: m3uImage || 'https://i.ibb.co/Hdp8G3R/video.png',
          region: m3uRegion,
        });

        m3uUrl = '', m3uTitle = '', m3uImage = '', m3uGroup = '';
        break;

      case '#EXTGRP':
        var match = line.match(/#EXTGRP:(.*)/);
        if (match) {
          m3uGroup = match[1].trim();
          if (groups.indexOf(m3uGroup) < 0) {
            groups.push(m3uGroup);
          }
        }
        break;

      case '#EXTVLC':
        var match = line.match(/http-(user-agent=[\s\S]*)$/);
        if (match) {
          m3uUA = match[1];
        }
        break;

      default:
        if (line[0] == '#') {
          continue; 
        }
        line = line.replace(/rtmp:\/\/\$OPT:rtmp-raw=/, '');
        if (line.indexOf(':') == -1 && line.length == 40) {
          line = 'acestream://' + line;
        }

        if (m3uImage && m3uImage.substr(0, 4) != 'http') {
          m3uImage = line.match(/^.+?[^\/:](?=[?\/]|$)/) + '/' + m3uImage;
        }

        m3uHeaders = line.match(/([\s\S]*?)\|([\s\S]*?)$/);
        m3uHeaders ? line = m3uHeaders[1] : '';
    }
  }
  console.log("Elementos cargados en m3uItems:", m3uItems);
  page.metadata.title = title;
}

function addItem(page, url, title, icon, description, genre, headers) {
  var type = 'video';
  var link = url.match(/([\s\S]*?):(.*)/);
  var linkUrl = 0;
  var playlistType = isPlaylist(url);
  if (link && playlistType) {
    link = linkUrl = playlistType + ':' + encodeURIComponent(url) + ':' + escape(title);
    type = 'video';
  } else
  if (link && !link[1].toUpperCase().match(/HTTP/) && !link[1].toUpperCase().match(/RTMP/)) {
    link = linkUrl = plugin.id + ':' + url + ':' + escape(title);
  } else {
    linkUrl = url.toUpperCase().match(/M3U8/) || url.toUpperCase().match(/\.SMIL/) ? 'hls:' + url : url;
    link = 'videoparams:' + JSON.stringify({
      title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
      icon: icon ? icon : 'https://i.ibb.co/xj573br/Carpetas.jpg',
      sources: [{
        url: linkUrl,
      }],
      no_fs_scan: true,
      no_subtitle_scan: true,
    });
  }

  if (!icon && description) {
    icon = description.match(/img src="([\s\S]*?)"/);
    if (icon) icon = icon[1];
  }
  if (!linkUrl) {
    var item = page.appendPassiveItem(type, '', {
      title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
      icon: icon ? icon : 'https://i.ibb.co/xj573br/Carpetas.jpg',
    });
  } else {
    if (headers) {
      io.httpInspectorCreate('.*' + url.replace('http://', '').replace('https://', '').split(/[/?#]/)[0].replace(/\./g, '\\.') + '.*', function(req) {
        var tmp = headers.split('|');
        for (i in tmp) {
          var header = unescape(tmp[i].replace(/\"/g, '')).match(/([\s\S]*?)=([\s\S]*?)$/);
          if (header) {
            req.setHeader(header[1], header[2]);
          }
        }
      });
    }
    var type = 'video';
    var item = page.appendItem(link, type, {
      title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
      icon: icon ? icon : 'https://i.ibb.co/xj573br/Carpetas.jpg',
      type: type,
    });
    addOptionForAddingToMyFavorites(item, link, title, icon, type);
  }
}

function showM3U(page, pl) {
  var num = 0;
  for (var i in groups) {
    if (groups[i]) {
      var groupLogo = 'https://i.ibb.co/xj573br/Carpetas.jpg';
      page.appendItem('PlayStr3amGroup:' + pl + ':' + encodeURIComponent(groups[i]), 'video', {
        title: new RichText(coloredStr('<b>' + groups[i] + '</b>', orange)),
        icon: groupLogo
      });
    }
    num++;
  }

  for (var i in m3uItems) {
    if (m3uItems[i].group) {
      continue;
    }
    var extension = m3uItems[i].url.split('.').pop().toUpperCase();
    var itemLogo = m3uItems[i].logo || 'https://i.ibb.co/xj573br/Carpetas.jpg';
    if (isPlaylist(m3uItems[i].url) || (m3uItems[i].url == m3uItems[i].title)) {
      var route = 'PlayStr3am:';
      if (m3uItems[i].url.substr(0, 4) == 'PlayStr3am:') {
        m3uItems[i].url = m3uItems[i].url.replace('PlayStr3am:', '');
      }
      var link = encodeURIComponent(m3uItems[i].url);
      var title = m3uItems[i].title;
      var icon = itemLogo
      var type = 'm3u'
      var item = page.appendItem(route + link + ':' + title, 'video', {
        title: new RichText(coloredStr('<b>' + title + '</b>', orange)),
        icon: icon,
	type: type,
      });
      addOptionForAddingToMyFavorites(item, link, title, icon, type);
      num++;
    } else {
      var description = '';
      addItem(page, m3uItems[i].url, m3uItems[i].title, m3uItems[i].logo, description, '', m3uItems[i].headers);
      epgForTitle = '';
      num++;
    }
    page.metadata.title = 'PlayStr3am';
  }

  if (num > 50) {
    popup.notify("Resultados Encontrados: " + num, 5); // Notificación visible por 5 segundos
  }

  return num;
}

//Paginas

page.Route(plugin.id + ':start', function(page) {
  setPageHeader(page, plugin.title);
  page.loading = true;
  validarUrl(page);
  checkupdate(page);
  var historial = JSON.parse(browser.list || '[]');
  var favoritos = JSON.parse(favorites.list || '[]');
  var pl = scraper + "code?codigo=" + encodeURIComponent(service.userCode);

  try {
    readAndParseM3U(page, pl);
    page.appendItem(plugin.id + ":buscar::", "search", {
        title: "Busqueda Global...",
    });
    page.appendItem('', 'separator', {
      title: '',
    });
  } catch (error) {
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }
  showM3U(page, pl);

  if (!service.disableHistorial && historial.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Ultimas Busquedas</i> ==★== </b>', orange)),
    });

    showUltBrowser(page); 

    if (!service.disableHistorial && historial.length > 9) {
      page.appendItem(plugin.id + ":historial", "video", {
        title: new RichText(coloredStr('<b>Mirar Mas...</b>', orange)),
        icon: 'https://i.ibb.co/2n8dMTS/mas.png',
      });
    } 
  }

  if (!service.disableMyFavorites && favoritos.length > 0) {
    page.appendItem('', 'separator', {
      title: new RichText(coloredStr('<b>==★== <i>Ultimos Favoritos</i> ==★== </b>', orange)),
    });

    showUltFavorites(page);  

    if (!service.disableMyFavorites && favoritos.length > 9) {
      page.appendItem(plugin.id + ":favorites", "video", {
        title: new RichText(coloredStr('<b>Mirar Mas...</b>', orange)),
        icon: 'https://i.ibb.co/2n8dMTS/mas.png'
      });    
    }
  }
  popup.notify("¡Bienvenido, " + service.userName + "! Disfruta del Contenido.",5 );
  page.loading = false;
});

new page.Route(plugin.id + ':favorites', function(page) {
  setPageHeader(page, 'Tus Favoritos');
  page.loading = true;
  validarUrl(page);
  fill_fav(page);

  page.options.createAction('cleanFavorites', 'Vacía Tus Favoritos', function() {
    favorites.list = '[]';
    popup.notify('Tus Favoritos se han vaciado exitosamente', 3);
    page.redirect(plugin.id + ':start');
  });
  page.loading = false;
});

new page.Route(plugin.id + ":buscar:(.*)?:(.*)?", function (page, pl, query) {
    console.log("Consulta recibida:", query);
    setPageHeader(page, "Busqueda: " + query);
    page.loading = true;
    validarUrl(page);
    showBrowser(page);
    try {
        if (query && query.trim()) {
            var busqueda = encodeURIComponent(query.trim());
	    var busquedaTitle = encodeURIComponent(busqueda);
            var urlBusqueda;
            
            if (pl && pl.trim()) {
                var listaUrl = encodeURIComponent(decodeURIComponent(pl));
                urlBusqueda = scraper + 'buscar?codigo=' + service.userCode + '&lista=' + listaUrl + '&query=' + busquedaTitle;
            } else {
                urlBusqueda = scraper + 'global?codigo=' + service.userCode + '&query=' + busquedaTitle;
            }

            var entry = JSON.stringify({
                title: busqueda,
                link: urlBusqueda,
            });

            var browserData = JSON.parse(browser.list || '[]');
            browserData.unshift(entry);
            browser.list = JSON.stringify(browserData);
 
            popup.notify('Buscando \'' + query + '\'...', 2);
            page.redirect('PlayStr3am:' + urlBusqueda + ':Resultados');
        } else {
            popup.notify('Búsqueda cancelada o término vacío', 2);
        }
    } catch (e) {
        popup.notify('Error al procesar la búsqueda: ' + e.message, 5);
    }
    page.loading = false;
});

new page.Route(plugin.id + ":historial", function(page) {
    setPageHeader(page, "Historial de Busqueda");
    page.loading = true;
    validarUrl(page);
    showBrowser(page);

    page.options.createAction('cleanRecord', 'Vacía Tu Historial', function() {
      browser.list = '[]';
      popup.notify('Tu Historial de Busqueda se ha vaciado exitosamente', 3);
      page.redirect(plugin.id + ':start');
    });
    page.loading = false;
});

new page.Route('PlayStr3amGroup:(.*):(.*)', function(page, pl, groupID) {
  setPageHeader(page, decodeURIComponent(groupID));
  page.loading = true;
  validarUrl(page);

  try {
    if (theLastList != pl) {
      readAndParseM3U(page, pl);
    }
  } catch (error) {
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }

  if (!m3uItems || m3uItems.length === 0) {
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }

  var num = 0;
  for (var i in m3uItems) {
    if (decodeURIComponent(groupID) != m3uItems[i].group) {
      continue;
    }
    addItem(page, m3uItems[i].url, m3uItems[i].title, m3uItems[i].logo, '', '', '', m3uItems[i].headers);
    num++;
  }

  if (num === 0) {
    page.error('No se encontraron resultados');
  }

  page.metadata.title = decodeURIComponent(groupID);
  page.loading = false;
});

new page.Route('PlayStr3am:(.*):(.*)', function(page, pl, title) {
  setPageHeader(page, unescape(title));
  validarUrl(page);
  page.loading = true;

  try {
    readAndParseM3U(page, pl);
    page.appendItem(plugin.id + ":buscar:" + encodeURIComponent(pl) + ":", "search", {
        title: "Busca en esta lista...",
    });
    page.appendItem('', 'separator', {
      title: '',
    });
  } catch (error) {
    page.error('Tu Código Expiró, Genera uno Nuevo');
    return;
  }

  if (!m3uItems || m3uItems.length === 0) {
    page.error('No se encontraron resultados');
    return;
  }

  page.metadata.title = new RichText(decodeURIComponent(title));
  showM3U(page, pl);
  page.loading = false;
});

o = {
  y: 'xx???x=xx??x?=',
};
// function fd2(x) {
//     var a;
//     eval(decode('#2aHR0cDovL3t2//OTcwZTYzMmUtMm//MzNmM2I4N2EtMWM3Yy00MDc2LWE2ODktNTVjNTZh//Y2UyMTczZjctZjAwNC00Njk5LWFmYmQtYzEwNzQ3MzYyZmQ0NmQwOWQ3Q4MC00N2M5LTg1ZTMtMjkxMGM0MmNiOGRmMn06e3YzfS9oMi9pbmRleC5tM3U4P3dtc0F1dGhTaWduPTE1ODAxODk2MzVTZWQxNzhhMDI1MzUwNTg4MzFkNjBkNjlhYzE2ZGEzM2RTOD//M//NDRkMWU0NjctZjI0Ni00NjY5LTkyZTEtOGVlNmI2YjNiMzE02Q0Nzg4ZjUtZWY1MC00MzI5LWFmYjYtYzQwMGFlMDg5N2ZhZoNzNoMDloMjEy'));
//     return a
// }

function fd2(x) {
  var a;
  a = x.substr(2);
  for (var i = 4; i > -1; i--) {
    if (exist(v['bk' + i])) {
      if (v['bk' + i] != '') {
        a = a.replace(v.file3_separator + b1(v['bk' + i]), '');
      }
    }
  }
  try {
    a = b2(a);
  } catch (e) {
    a = '';
  }

  function b1(str) {
    // console.log(unescape(str));
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
          return String.fromCharCode('0x' + p1);
        }));
  }

  function b2(str) {
    return decodeURIComponent(atob(str).split('').map(function(c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  }
  return a;
}

var dechar = function(x) {
  return String.fromCharCode(x);
};
var decode = function(x) {
  if (x.substr(0, 2) == '#1') {
    return salt.d(pepper(x.substr(2), -1));
  } else if (x.substr(0, 2) == '#0') {
    return salt.d(x.substr(2));
  } else {
    return x;
  }
};
var abc = String.fromCharCode(65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122);
var salt = {
  _keyStr: abc + '0123456789+/=',
  e: function(e) {
    var t = '';
    var n, r, i, s, o, u, a;
    var f = 0;
    e = salt._ue(e);
    while (f < e.length) {
      n = e.charCodeAt(f++);
      r = e.charCodeAt(f++);
      i = e.charCodeAt(f++);
      s = n >> 2;
      o = (n & 3) << 4 | r >> 4;
      u = (r & 15) << 2 | i >> 6;
      a = i & 63;
      if (isNaN(r)) {
        u = a = 64;
      } else if (isNaN(i)) {
        a = 64;
      }
      t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a);
    }
    return t;
  },
  d: function(e) {
    var t = '';
    var n, r, i;
    var s, o, u, a;
    var f = 0;
    e = e.replace(/[^A-Za-z0-9\+\/\=]/g, '');
    while (f < e.length) {
      s = this._keyStr.indexOf(e.charAt(f++));
      o = this._keyStr.indexOf(e.charAt(f++));
      u = this._keyStr.indexOf(e.charAt(f++));
      a = this._keyStr.indexOf(e.charAt(f++));
      n = s << 2 | o >> 4;
      r = (o & 15) << 4 | u >> 2;
      i = (u & 3) << 6 | a;
      t = t + dechar(n);
      if (u != 64) {
        t = t + dechar(r);
      }
      if (a != 64) {
        t = t + dechar(i);
      }
    }
    t = salt._ud(t);
    return t;
  },
  _ue: function(e) {
    e = e.replace(/\r\n/g, '\n');
    var t = '';
    for (var n = 0; n < e.length; n++) {
      var r = e.charCodeAt(n);
      if (r < 128) {
        t += dechar(r);
      } else if (r > 127 && r < 2048) {
        t += dechar(r >> 6 | 192);
        t += dechar(r & 63 | 128);
      } else {
        t += dechar(r >> 12 | 224);
        t += dechar(r >> 6 & 63 | 128);
        t += dechar(r & 63 | 128);
      }
    }
    return t;
  },
  _ud: function(e) {
    var t = '';
    var n = 0;
    var r = 0;
    var c1 = 0;
    var c2 = 0;
    while (n < e.length) {
      r = e.charCodeAt(n);
      if (r < 128) {
        t += dechar(r);
        n++;
      } else if (r > 191 && r < 224) {
        c2 = e.charCodeAt(n + 1);
        t += dechar((r & 31) << 6 | c2 & 63);
        n += 2;
      } else {
        c2 = e.charCodeAt(n + 1);
        c3 = e.charCodeAt(n + 2);
        t += dechar((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
        n += 3;
      }
    }
    return t;
  },
};
var pepper = function(s, n) {
  s = s.replace(/\+/g, '#');
  s = s.replace(/#/g, '+');
  var a = sugar(o.y) * n;
  if (n < 0) a += abc.length / 2;
  var r = abc.substr(a * 2) + abc.substr(0, a * 2);
  return s.replace(/[A-Za-z]/g, function(c) {
    return r.charAt(abc.indexOf(c));
  });
};
var sugar = function(x) {
  x = x.split(dechar(61));
  var result = '';
  var c1 = dechar(120);
  var chr;
  for (var i in x) {
    if (x.hasOwnProperty(i)) {
      var encoded = '';
      for (var j in x[i]) {
        if (x[i].hasOwnProperty(j)) {
          encoded += (x[i][j] == c1) ? dechar(49) : dechar(48);
        }
      }
      chr = parseInt(encoded, 2);
      result += dechar(chr.toString(10));
    }
  }
  return result.substr(0, result.length - 1);
};
var exist = function(x) {
  return x != null && typeof (x) != 'undefined';
};


var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';

function InvalidCharacterError(message) {
  this.message = message;
}
InvalidCharacterError.prototype = new Error();
InvalidCharacterError.prototype.name = 'InvalidCharacterError';

function btoa(input) {
  var str = String(input);
  for (
    // initialize result and counter
    var block, charCode, idx = 0, map = chars, output = '';
    // if the next str index does not exist:
    //   change the mapping table to "="
    //   check if d has no fractional digits
    str.charAt(idx | 0) || (map = '=', idx % 1);
    // "8 - idx % 1 * 8" generates the sequence 2, 4, 6, 8
    output += map.charAt(63 & block >> 8 - idx % 1 * 8)
  ) {
    charCode = str.charCodeAt(idx += 3 / 4);
    if (charCode > 0xFF) {
      throw new InvalidCharacterError('\'btoa\' failed: The string to be encoded contains characters outside of the Latin1 range.');
    }
    block = block << 8 | charCode;
  }
  return output;
}

// decoder
// [https://gist.github.com/1020396] by [https://github.com/atk]
function atob(input) {
  var str = (String(input)).replace(/[=]+$/, ''); // #31: ExtendScript bad parse of /=
  if (str.length % 4 === 1) {
    throw new InvalidCharacterError('\'atob\' failed: The string to be decoded is not correctly encoded.');
  }
  for (
    // initialize result and counters
    var bc = 0, bs, buffer, idx = 0, output = '';
    // get next character
    buffer = str.charAt(idx++); // eslint-disable-line no-cond-assign
    // character found in table? initialize bit storage and add its ascii value;
    ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer,
    // and if not first of each 4 characters,
    // convert the first 8 bits to one ascii character
    bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0
  ) {
    // try to find character in table (0-63, not found => -1)
    buffer = chars.indexOf(buffer);
  }
  return output;
}